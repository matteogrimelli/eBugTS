<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateAffidamentoSoftwareTable extends Migration {

	/**
	 * Run the migrations.
	 *
	 * @return void
	 */
	public function up()
	{
		Schema::create('affidamentoSoftware', function(Blueprint $table)
		{
			$table->integer('IDAffidamento', true);
			$table->integer('idSoftware')->index('idSoftware');
			$table->integer('idProgrammatore')->index('idProgrammatore');
			$table->timestamps();
		});
	}


	/**
	 * Reverse the migrations.
	 *
	 * @return void
	 */
	public function down()
	{
		Schema::drop('affidamentoSoftware');
	}

}
