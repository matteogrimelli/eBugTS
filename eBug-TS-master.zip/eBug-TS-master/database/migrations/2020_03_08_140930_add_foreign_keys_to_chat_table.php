<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;

class AddForeignKeysToChatTable extends Migration {

	/**
	 * Run the migrations.
	 *
	 * @return void
	 */
	public function up()
	{
		Schema::table('chat', function(Blueprint $table)
		{
			$table->foreign('idProprietario', 'chat_ibfk_1')->references('IDDipendente')->on('dipendenti')->onUpdate('RESTRICT')->onDelete('RESTRICT');
			$table->foreign('idDestinatario', 'chat_ibfk_2')->references('IDDipendente')->on('dipendenti')->onUpdate('RESTRICT')->onDelete('RESTRICT');
		});
	}


	/**
	 * Reverse the migrations.
	 *
	 * @return void
	 */
	public function down()
	{
		Schema::table('chat', function(Blueprint $table)
		{
			$table->dropForeign('chat_ibfk_1');
			$table->dropForeign('chat_ibfk_2');
		});
	}

}
