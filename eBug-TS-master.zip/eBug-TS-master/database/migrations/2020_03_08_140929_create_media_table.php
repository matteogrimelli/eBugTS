<?php

use App\Media;
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateMediaTable extends Migration {

	/**
	 * Run the migrations.
	 *
	 * @return void
	 */
	public function up()
	{
		Schema::create('media', function(Blueprint $table)
		{
			$table->integer('IDMedia', true);
            $table->string('urlMedia', 100);
            $table->timestamps();
        });

        // Default profile Media
        Media::create(['urlMedia' => 'storage/images/default/default_male_1.png']);
        Media::create(['urlMedia' => 'storage/images/default/default_male_2.png']);
        Media::create(['urlMedia' => 'storage/images/default/default_female_1.png']);
        Media::create(['urlMedia' => 'storage/images/default/default_female_2.png']);
        Media::create(['urlMedia' => 'storage/images/default/default_client_1.svg']);
		Media::create(['urlMedia' => 'storage/images/default/default_coder_1.svg']);
		Media::create(['urlMedia' => 'storage/images/default/create-back.jpg']);
		Media::create(['urlMedia' => 'storage/images/default/find-back.jpg']);
	}


	/**
	 * Reverse the migrations.
	 *
	 * @return void
	 */
	public function down()
	{
		Schema::drop('media');
	}

}
