<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateAziendeTable extends Migration {

	/**
	 * Run the migrations.
	 *
	 * @return void
	 */
	public function up()
	{
		Schema::create('aziende', function(Blueprint $table)
		{
			$table->integer('IDAzienda', true);
			$table->string('email', 60)->nullable();
			$table->string('nome', 40);
			$table->string('telefono', 10)->nullable();
			$table->tinyInteger('tipoAzienda');
			$table->string('localita', 100)->nullable();
			$table->timestamps();
			$table->integer('idMedia')->nullable()->index('idMedia');
		});
	}


	/**
	 * Reverse the migrations.
	 *
	 * @return void
	 */
	public function down()
	{
		Schema::drop('aziende');
	}

}
