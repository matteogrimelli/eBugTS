<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;

class CreateDipendentiTable extends Migration {

	/**
	 * Run the migrations.
	 *
	 * @return void
	 */
	public function up()
	{
		Schema::create('dipendenti', function(Blueprint $table)
		{
			$table->integer('IDDipendente', true);
            $table->string('username')->unique();
			$table->string('email')->unique();
			$table->string('password');
			$table->string('nome', 60);
			$table->string('cognome', 60);
			$table->string('telefono', 10);
			$table->integer('livAzienda')->default(1);
            $table->timestamp('email_verified_at')->nullable();
            $table->rememberToken();
            $table->timestamps();
			$table->integer('idMedia')->nullable()->index('idMedia');
			$table->integer('idAzienda')->nullable()->index('idAzienda');
		});
	}


	/**
	 * Reverse the migrations.
	 *
	 * @return void
	 */
	public function down()
	{
		Schema::drop('dipendenti');
	}
	
}
