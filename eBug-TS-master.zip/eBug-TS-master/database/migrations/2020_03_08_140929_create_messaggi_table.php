<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateMessaggiTable extends Migration {

	/**
	 * Run the migrations.
	 *
	 * @return void
	 */
	public function up()
	{
		Schema::create('messaggi', function(Blueprint $table)
		{
			$table->integer('IDMessaggio', true);
			$table->string('testo', 1000);
			$table->timestamps();
			$table->integer('idMedia')->nullable()->index('idMedia');
			$table->integer('idMittente')->index('idMittente');
			$table->integer('idDestinatario')->index('idDestinatario');
		});
	}


	/**
	 * Reverse the migrations.
	 *
	 * @return void
	 */
	public function down()
	{
		Schema::drop('messaggi');
	}

}
