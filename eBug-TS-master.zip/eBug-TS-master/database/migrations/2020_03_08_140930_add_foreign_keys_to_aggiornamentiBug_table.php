<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class AddForeignKeysToAggiornamentiBugTable extends Migration {

	/**
	 * Run the migrations.
	 *
	 * @return void
	 */
	public function up()
	{
		Schema::table('aggiornamentiBug', function(Blueprint $table)
		{
			$table->foreign('idBug', 'aggiornamentiBug_ibfk_1')->references('IDBug')->on('bugs')->onUpdate('RESTRICT')->onDelete('RESTRICT');
			$table->foreign('idCreatore', 'aggiornamentiBug_ibfk_2')->references('IDDipendente')->on('dipendenti')->onUpdate('RESTRICT')->onDelete('RESTRICT');
			$table->foreign('idMedia', 'aggiornamentiBug_ibfk_3')->references('IDMedia')->on('media')->onUpdate('RESTRICT')->onDelete('RESTRICT');
		});
	}


	/**
	 * Reverse the migrations.
	 *
	 * @return void
	 */
	public function down()
	{
		Schema::table('aggiornamentiBug', function(Blueprint $table)
		{
			$table->dropForeign('aggiornamentiBug_ibfk_1');
			$table->dropForeign('aggiornamentiBug_ibfk_2');
			$table->dropForeign('aggiornamentiBug_ibfk_3');
		});
	}

}
