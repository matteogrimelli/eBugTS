<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateAggiornamentiBugTable extends Migration {

	/**
	 * Run the migrations.
	 *
	 * @return void
	 */
	public function up()
	{
		Schema::create('aggiornamentiBug', function(Blueprint $table)
		{
			$table->integer('IDAggiornamento', true);
			$table->string('messaggio', 1000);
            $table->timestamps();
			$table->integer('idMedia')->nullable()->index('idMedia');
			$table->integer('idBug')->index('idBug');
			$table->integer('idCreatore')->index('idCreatore');
		});
	}


	/**
	 * Reverse the migrations.
	 *
	 * @return void
	 */
	public function down()
	{
		Schema::drop('aggiornamentiBug');
	}

}
