<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateBugsTable extends Migration {

	/**
	 * Run the migrations.
	 *
	 * @return void
	 */
	public function up()
	{
		Schema::create('bugs', function(Blueprint $table)
		{
			$table->integer('IDBug', true);
			$table->integer('relative_id');
			$table->boolean('urgenza');
			$table->boolean('stato');
            $table->timestamps();
			$table->integer('idSegnalatore');
			$table->integer('idSoftware')->index('idSoftware');
		});
	}


	/**
	 * Reverse the migrations.
	 *
	 * @return void
	 */
	public function down()
	{
		Schema::drop('bugs');
	}

}
