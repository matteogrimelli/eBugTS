<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class AddForeignKeysToBugsTable extends Migration {

	/**
	 * Run the migrations.
	 *
	 * @return void
	 */
	public function up()
	{
		Schema::table('bugs', function(Blueprint $table)
		{
			$table->foreign('idSoftware', 'bugs_ibfk_1')->references('IDSoftware')->on('softwares')->onUpdate('RESTRICT')->onDelete('RESTRICT');
            $table->foreign('idSegnalatore', 'bugs_ibfk_3')->references('IDDipendente')->on('dipendenti')->onUpdate('RESTRICT')->onDelete('RESTRICT');
        });
	}


	/**
	 * Reverse the migrations.
	 *
	 * @return void
	 */
	public function down()
	{
		Schema::table('bugs', function(Blueprint $table)
		{
			$table->dropForeign('bugs_ibfk_1');
		});
	}

}
