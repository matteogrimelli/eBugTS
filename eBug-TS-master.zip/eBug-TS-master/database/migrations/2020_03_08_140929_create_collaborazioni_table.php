<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateCollaborazioniTable extends Migration {

	/**
	 * Run the migrations.
	 *
	 * @return void
	 */
	public function up()
	{
		Schema::create('collaborazioni', function(Blueprint $table)
		{
			$table->integer('IDCollaborazione', true);
			$table->timestamps();
			$table->integer('idAziendaClienti')->index('idAziendaClienti');
			$table->integer('idAziendaProgrammatori')->index('idAziendaProgrammatori');
		});
	}


	/**
	 * Reverse the migrations.
	 *
	 * @return void
	 */
	public function down()
	{
		Schema::drop('collaborazioni');
	}

}
