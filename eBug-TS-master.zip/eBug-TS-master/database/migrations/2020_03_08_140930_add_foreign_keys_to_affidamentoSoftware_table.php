<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class AddForeignKeysToAffidamentoSoftwareTable extends Migration {

	/**
	 * Run the migrations.
	 *
	 * @return void
	 */
	public function up()
	{
		Schema::table('affidamentoSoftware', function(Blueprint $table)
		{
			$table->foreign('idProgrammatore', 'affidamentoSoftware_ibfk_1')->references('IDDipendente')->on('dipendenti')->onUpdate('RESTRICT')->onDelete('RESTRICT');
			$table->foreign('idSoftware', 'affidamentoSoftware_ibfk_2')->references('IDSoftware')->on('softwares')->onUpdate('RESTRICT')->onDelete('RESTRICT');
		});
	}


	/**
	 * Reverse the migrations.
	 *
	 * @return void
	 */
	public function down()
	{
		Schema::table('affidamentoSoftware', function(Blueprint $table)
		{
			$table->dropForeign('affidamentoSoftware_ibfk_1');
			$table->dropForeign('affidamentoSoftware_ibfk_2');
		});
	}

}
