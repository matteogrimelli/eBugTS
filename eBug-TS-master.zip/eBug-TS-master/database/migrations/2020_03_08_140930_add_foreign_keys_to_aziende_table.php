<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class AddForeignKeysToAziendeTable extends Migration {

	/**
	 * Run the migrations.
	 *
	 * @return void
	 */
	public function up()
	{
		Schema::table('aziende', function(Blueprint $table)
		{
			$table->foreign('idMedia', 'aziende_ibfk_1')->references('IDMedia')->on('media')->onUpdate('RESTRICT')->onDelete('RESTRICT');
		});
	}


	/**
	 * Reverse the migrations.
	 *
	 * @return void
	 */
	public function down()
	{
		Schema::table('aziende', function(Blueprint $table)
		{
			$table->dropForeign('aziende_ibfk_1');
		});
	}

}
