<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class AddForeignKeysToDipendentiTable extends Migration {

	/**
	 * Run the migrations.
	 *
	 * @return void
	 */
	public function up()
	{
		Schema::table('dipendenti', function(Blueprint $table)
		{
			$table->foreign('idAzienda', 'dipendenti_ibfk_1')->references('IDAzienda')->on('aziende')->onUpdate('RESTRICT')->onDelete('RESTRICT');
			$table->foreign('idMedia', 'dipendenti_ibfk_2')->references('IDMedia')->on('media')->onUpdate('RESTRICT')->onDelete('RESTRICT');
		});
	}


	/**
	 * Reverse the migrations.
	 *
	 * @return void
	 */
	public function down()
	{
		Schema::table('dipendenti', function(Blueprint $table)
		{
			$table->dropForeign('dipendenti_ibfk_1');
			$table->dropForeign('dipendenti_ibfk_2');
		});
	}

}
