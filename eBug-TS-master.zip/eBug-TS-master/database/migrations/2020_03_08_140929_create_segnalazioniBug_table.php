<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateSegnalazioniBugTable extends Migration {

	/**
	 * Run the migrations.
	 *
	 * @return void
	 */
	public function up()
	{
		Schema::create('segnalazioniBug', function(Blueprint $table)
		{
			$table->integer('IDSegnalazioneBug', true);
			$table->boolean('isNotificato');
			$table->integer('idMittente');
			$table->integer('idProgrammatore')->index('idProgrammatore');
			$table->integer('idBug')->index('idBug');
			$table->timestamps();
		});
	}


	/**
	 * Reverse the migrations.
	 *
	 * @return void
	 */
	public function down()
	{
		Schema::drop('segnalazioniBug');
	}

}
