<footer>
    <ul class="list-inline">
        <li class="list-inline-item"><a href="{{route('home')}}">Home</a></li>
        <li class="list-inline-item"><a href="{{route('tutorial')}}">Tutorial</a></li>
        <li class="list-inline-item"><a href="{{route('terms')}}">Terms</a></li>
        <li class="list-inline-item"><a href="{{route('privacy-policy')}}">Privacy Policy</a></li>
    </ul>
    <p class="copyright">eBugTS © 2020</p>
</footer>