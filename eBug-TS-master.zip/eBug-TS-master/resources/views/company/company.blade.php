@extends('layouts.layout')

@section('content')
<script src="{{asset('js/company.js')}}" defer></script>
<div class="modal fade modalBg mt-5" id="modalA" tabindex="-1" role="dialog" aria-labelledby="modalALabel">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header" style="background-color: rgb(36,41,46); color: white;">
                <h4 class="modal-title" id="modalALabel">Inserisci commento</h4>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true"
                        style="color: white; font-size: 30px;">&times;</span></button>
            </div>
            <div class="modal-body">
                    <label id="url-user">Invia questo link al dipendente da invitare</label>
                    <input type="text" readonly id="url-popup" cols="30" rows="10" class="form-control ModalTa">
            </div>
            <div class="modal-footer" style="background-color: rgb(218,218,218);">
                <button type="button" class="btn btn-default btnClose" data-dismiss="modal">Chiudi</button>
            </div>
        </div>
    </div>
</div>
<div class="container-fluid">
    <h3 class="text-dark mb-4" style="font-size: 36px;">{{ $company->nome }}</h3>
    <div class="row mb-3">
        <div class="col-lg-4">
            <div class="card mb-3">
                <div class="card-body text-center shadow"><img class="rounded-circle mb-3 mt-4"
                        src={{ asset($company->urlMedia) }} width="160" height="160"
                        style="width: 150px;height: 150px;border: 3px solid rgb(33,37,41);">
                    <div class="mb-3"></div>
                </div>
            </div>
            <div class="card shadow mb-3">
                <div class="card-header py-3" style="background-color: rgb(255,255,255);">
                    <p class="text-primary m-1 font-weight-bold" style="font-size: 16px;color: rgb(255,255,255);">
                        <strong>{{ $company->localita }}</strong></p>
                    <p class="text-primary m-1 font-weight-bold" style="font-size: 16px;color: rgb(255,255,255);">Email:
                        {{ $company->email }}</p>
                    <p class="text-primary m-1 font-weight-bold" style="font-size: 16px;color: rgb(255,255,255);">Phone
                        number: {{ $company->telefono }}</p>
                </div>
            </div>
            <div class="card shadow mb-3">
                <button id="add-dipendente" class="btn" style="background-color: rgb(36, 41, 46);" data-toggle="modal" data-target="#modalA" >
                    <p class="text-primary m-0 font-weight-bold" style="font-size: 20px; color: rgb(255, 255, 255);">
                        Aggiungi dipendente </p>
                </button>
            </div>
        </div>
        <div class="col-lg-8">
            <div class="row">
                <div class="col">
                    <div class="card shadow mb-3">
                        <div class="card-header py-3" style="background-color: rgb(36,41,46);">
                            <p class="text-primary m-0 font-weight-bold"
                                style="font-size: 20px;color: rgb(255,255,255);">Software list</p>
                        </div>
                    </div>
                    <div class="card shadow">
                        <div class="card-body">
                            <ul class="list-unstyled">
                                @foreach($softwares as $software)
                                    <li>
                                        <div><a class="d-inline-flex 5 mb-2"><img class="mr-2"
                                                    src={{ asset('storage/images/default/software.svg') }}
                                                    style="width: 20px;height: 20px;"><span>{{ $software }}</span></a>
                                        </div>
                                    </li>
                                @endforeach
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row" style="padding-top: 40px;">
                <div class="col">
                    <div class="card shadow mb-3">
                        <div class="card-header py-3" style="background-color: rgb(36,41,46);">
                            <p class="text-primary m-0 font-weight-bold"
                                style="font-size: 20px;color: rgb(255,255,255);">Affiliates</p>
                        </div>
                    </div>
                    <div class="card shadow">
                        <div class="card-body">
                            <ul class="list-unstyled">
                                @foreach($affiliates as $affiliate)
                                    <li>
                                        <div><a class="d-inline-flex 5 mb-2"><span>{{ $affiliate }}</span></a></div>
                                    </li>
                                @endforeach
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

@endsection
