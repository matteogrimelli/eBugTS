@extends('layouts.layout-navbar')

@section('content')
<div class="modal fade modalBg mt-5" id="modalA" tabindex="-1" role="dialog" aria-labelledby="modalALabel">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header" style="background-color: rgb(36,41,46); color: white;">
                <h4 class="modal-title" id="modalALabel">Cosa fare</h4>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true"
                        style="color: white; font-size: 30px;">&times;</span></button>
            </div>
            <div class="modal-body">
                <p><mark> Chiedi al creatore dell'account della tua azienda di inviarti un link di invito </mark> </p>
            </div>
            <div class="modal-footer" style="background-color: rgb(218,218,218);">
                <button type="button" class="btn btn-default btnClose" data-dismiss="modal">Chiudi</button>
            </div>
        </div>
    </div>
</div>
<div style="margin: 30px;">
    <header class="masthead text-white text-center">
        <div class="container">
            <div class="row row-shadow"
                style="background-color: #efeef5;border: solid 4px rgb(66,71,76);border-radius: 25px;">
                <div class="col-xl-9 mx-auto" style="height: 100px;">
                    <h1 class="mb-5"
                        style="color: rgb(36,41,46);margin-bottom: 0px;margin-top: 25px;font-family: sans-serif;">
                        <strong>Non fai parte di nessuna azienda: Iniziamo</strong></h1>
                </div>
                <div class="row" style="margin: auto">
                    <div class="col">
                        <button data-toggle="modal" data-target="#modalA" class="btn btn-primary"
                            type="button"
                            style="background-color: rgb(36,41,46);height: 150px;width: 300px;margin: 35px;background-image: url( {{ asset('storage/images/default/find-back.jpg') }} );"></button>
                    </div>
                    <div class="col">
                        <button onclick="location.href = '{{ route('create-company') }}';"
                            class="btn btn-primary" type="button"
                            style="background-color: rgb(36,41,46);height: 150px;width: 300px;margin: 35px;background-image: url( {{ asset('storage/images/default/create-back.jpg') }} );"></button>
                    </div>
                </div>
            </div>
        </div>
    </header>
</div>
<footer class="footer-basic">
    @include('footer')
</footer>

@endsection
