@extends('layouts.layout-navbar')

@section('content')
    <link href="{{ asset('css/company-create.css') }}" rel="stylesheet">

    <div class="register" accept="image/png, image/jpeg" style="background-color: rgb(229,225,225);">
        <div class="form-container">
            <form method="POST" action="/company/new" enctype="multipart/form-data">
                @csrf
                <h2 class="text-center"><strong>Create</strong> a company</h2>
                <div class="form-group"><input class="form-control" type="email" name="email" placeholder="Email"></div>
                <div class="form-group"><input class="form-control" type="text" name="nome" placeholder="Company Name"></div>
                <div class="form-group"><input class="form-control" type="text" name="telefono" placeholder="Telephone"></div>
                <div class="form-group">
                <select class="form-control" name="tipoAzienda">
                    <optgroup label="Select company type">
                        <option value="0" selected>Customers</option>
                        <option value="1">Developers</option>
                    </optgroup>
                </select>
                </div>
                <div class="form-group" id="image-input" style="background-color: rgb(149,155,158);"><label class="form-control">Select company image</label><input type="file" name="companyimage" class="image-input" style="color: rgb(255,255,255);"></div>
                <div class="form-group"><button class="btn btn-primary btn-block" type="submit" style="background-color: #24292e;">CONFERMA</button></div>
            </form>
        </div>
    </div>
    <div class="footer-basic">
        @include('footer')
    </div>
@endsection
