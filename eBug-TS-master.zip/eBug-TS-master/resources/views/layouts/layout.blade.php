<!doctype html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="{{ csrf_token() }}">

    <title>{{ config('app.name', 'Laravel') }}</title>

    <!-- Scripts -->
    <script src="{{ asset('js/app.js') }}" defer></script>
    <script src="{{ asset('js/chat.js') }}" defer></script>
    <script type="text/javascript" defer> var username_ = "{{ Auth::user()->username }}"; </script>

    <!-- Fonts --> 
    <link rel="dns-prefetch" href="//fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css?family=Nunito" rel="stylesheet">

    <!-- Styles -->
    <link href="{{ asset('css/app.css') }}" rel="stylesheet">
    <link href="{{ asset('css/chat.css') }}" rel="stylesheet">
    <link href="{{ asset('css/footer.css') }}" rel="stylesheet">
    <link href="{{ asset('css/navbar.css') }}" rel="stylesheet">
    <link href="{{ asset('css/ionicons.min.css') }}" rel="stylesheet">
    <link rel="stylesheet" href="https://kit-free.fontawesome.com/releases/latest/css/free.min.css">
    
</head>

<body>
    <div id="app" class="content-wrapper">
    @include('navbar')
    <div class="d-flex flex-wrap vh-100 bg-light">
        <aside class="col-12 col-md-4 col-lg-3 bg-white border-right border-bottom">
            <div class="top-0 px-3 px-md-4 px-lg-4 overflow-auto">
                <div class="mb-3 mt-5">
                    <h2 class="f4 mb-1 f5 d-flex" style="font-size: 30px;">Softwares 
                        @if($is_dev)
                            <a href="/software/new"> <button type="button" class="btn btn-primary btn-sm ml-3">New</button></a> 
                        @endif
                    </h2>
                    <br>
                    <ul class="list-unstyled">
                    @if($has_company and !empty($softwares))
                        @foreach ($softwares as $software)
                            <li>
                            <div><a class="d-inline-flex 5 mb-2" href="/company/{{urlencode($software)}}"><img class="mr-2" src={{asset('storage/images/default/software.svg')}} style="width: 20px;height: 20px;"><span>{{$software}}</span></a></div>
                            </li>
                        @endforeach
                    @else
                        <li>
                            <div><a class="d-inline-flex 5 mb-2"><span> 😢 There's nothing here </span></a></div>
                        </li>
                    @endif
                    </ul>
                </div>
            </div>
        </aside>
        <div class="col-12 col-md-8 col-lg-6 mt-3 border-bottom d-flex">
            <div class="mx-auto d-flex flex-auto flex-column" style="width: 100%;">

                <main class="flex-grow">
                    @yield('content')
                </main>
                
                <div class="fixed-bottom footer-basic position-absolute bg-light">
                    @include('footer')
                </div>
            </div>
        </div>
        <aside class="col-12 col-md-3 col-lg-3 pr-3 mt-5 border-bottom"></aside>
        <div class="border rounded position-absolute" id="chat-show" style="top: 100px;right: 0px;background-color: #24292e;"><i class="far fa-comment" style="font-size: 30px;color: rgb(255,255,255);margin: 3px;margin-right: 5px;margin-left: 5px;"></i></div>
        <div id="chat" class="position-absolute" style="display: none; top: 100px;right: 0px;">
            <div class="border rounded" id="chat-hide" style="background-color: #24292e;"><i class="fas fa-comment-slash" style="font-size: 30px;color: rgb(255,255,255);margin: 3px;margin-right: 5px;margin-left: 5px;"></i></div>
            <div class="border rounded" id="messages-hide" style="display: none; background-color: #24292e;"><i class="fas fa-arrow-left" style="font-size: 30px;color: rgb(255,255,255);margin: 3px;margin-right: 5px;margin-left: 5px;"></i></div>
            <div id="chat-list" class="container">
                <div class="row rounded-lg overflow-hidden shadow">
                    <div class="bg-white">
                        <div class="messages-box">
                            <ul id="chat-parent" class="list-group rounded-0">
                                @isset($visible_chats)
                                    @foreach($visible_chats as $visible_chat)
                                        <li class="list-group-item list-group-item-action list-group-item-light rounded-0 chat-person" username="{{$visible_chat['username']}}">
                                            <div class="media">
                                                <img class="rounded-circle" src="{{asset($visible_chat['urlMedia'])}}" width="50">
                                                <div class="media-body ml-4">
                                                <div class="d-flex align-items-center justify-content-between mb-1">
                                                    <h6 class="mb-0"> {{$visible_chat['nome'] . $visible_chat['cognome'] }} </h6></div>
                                                </div>
                                            </div>
                                        </li>
                                    @endforeach
                                @endisset
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
            <div id="messages-list" class="col-7-px-0">
                <ul id="messages-parent" class="list-group">
                @isset($visible_chats)
                    @foreach($visible_chats as $visible_chat)
                    <li class="list-group-item messages-person" username="{{$visible_chat['username']}}" style="display: none;">
                            <chat-form v-on:messagesent="addMessage" destinatario="{{$visible_chat['username']}}"></chat-form>
                    </li>
                    @endforeach
                @endisset
                </ul>
            </div>
        </div>
    </div>
    </div>
</body>

</html>
