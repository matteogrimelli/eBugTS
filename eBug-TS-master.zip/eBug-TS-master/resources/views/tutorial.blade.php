@extends('layouts.layout-navbar')
@section('content')

    <link href="{{asset('css/tutorial.css')}}" rel="stylesheet">
    <script src="{{asset('js/tutorial.js')}}" defer></script>
    <div class="tab">
  
    <h1> SELECT LANGUAGE</h1>
    
    <button class="tablinks" onclick="openTutorial(event, 'ITALIANO')">ITALIAN</button>
    <button class="tablinks" onclick="openTutorial(event, 'ENGLISH')">ENGLISH</button>
    
</div>

    <div id="ITALIANO" class="tabcontent">
    
        <iframe width="480" height="270" src="https://www.youtube.com/embed/G8dT0P8rcns" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
        
        <iframe width="480" height="270" src="https://www.youtube.com/embed/veM-4jOvdsI" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
        
        <iframe width="480" height="270" src="https://www.youtube.com/embed/vFLOPVabA6w" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
        
        <iframe width="480" height="270" src="https://www.youtube.com/embed/lkoFf24yz94" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
        
        <iframe width="480" height="270" src="https://www.youtube.com/embed/ws804enuikA" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
        
        <iframe width="480" height="270" src="https://www.youtube.com/embed/51gKXJFd7Gk" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
        
        <iframe width="480" height="270" src="https://www.youtube.com/embed/farVtWQ_2uY" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
        
    </div>

    <div id="ENGLISH" class="tabcontent">

        <iframe width="480" height="270" src="https://www.youtube.com/embed/6r9AiV5F0G4?list=PLsVOu_pSnCHgjQMUN14OofmcEImi0RhAT" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
    
        <iframe width="480" height="270" src="https://www.youtube.com/embed/VEcSpIMmQCE?list=PLsVOu_pSnCHgjQMUN14OofmcEImi0RhAT" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
       
        <iframe width="480" height="270" src="https://www.youtube.com/embed/OAU-zrQLQGo?list=PLsVOu_pSnCHgjQMUN14OofmcEImi0RhAT" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>

        <iframe width="480" height="270" src="https://www.youtube.com/embed/auDZJUnzIXc?list=PLsVOu_pSnCHgjQMUN14OofmcEImi0RhAT" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>

        <iframe width="480" height="270" src="https://www.youtube.com/embed/uaD1RkpIEyM?list=PLsVOu_pSnCHgjQMUN14OofmcEImi0RhAT" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
   
        <iframe width="480" height="270" src="https://www.youtube.com/embed/bZGTsMyMrx4?list=PLsVOu_pSnCHgjQMUN14OofmcEImi0RhAT" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
    
        <iframe width="480" height="270" src="https://www.youtube.com/embed/P-5kPn_lcws?list=PLsVOu_pSnCHgjQMUN14OofmcEImi0RhAT" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
    
    </div>

    <div class="footer-basic">
        @include('footer')
    </div>
@endsection