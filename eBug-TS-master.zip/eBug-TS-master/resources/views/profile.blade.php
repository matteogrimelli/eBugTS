@extends('layouts.layout')

@section('content')
<div class="container">
    <div class="row justify-content-center">
        <div class="text-center border rounded-0 shadow-sm profile-box" style="width: 200px;height: 300px;background-color: #ffffff;margin: 5px;">
            <div style="height: 50px;background-image: url('bg-pattern.png');background-color: rgba(54,162,177,0);"></div>
            <div><img class="rounded-circle" src={{ asset($img_url) }} width="60px" height="60px" style="background-color: rgb(255,255,255);padding: 2px;" /></div>
            <div style="height: 80px;">
            <h4>{{ $profile->username }}</h4>
                <p style="font-size: 12px;">Profile Description</p>
                <p>Nome: {{$profile->nome}}</p>
                <p>Cognome: {{$profile->cognome}}</p>
                <p>Telefono: {{$profile->telefono}}</p>
            </div>
        </div>
    </div>
</div>
@endsection
