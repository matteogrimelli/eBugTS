@extends('layouts.layout-navbar')

@section('content')
<script type="text/javascript" src="{{ asset('js/register.js') }}" defer></script>
<link href="{{ asset('css/register.css') }}" rel="stylesheet">
<div class="container">
    <div class="row justify-content-center">
        <div>
            <div class="signup-content">
                <form method="POST" action="{{ route('register') }}" id="signup-form" class="signup-form" enctype="multipart/form-data">
                    @csrf

                    <h2 class="form-title">Crea un account</h2>

                    @error('email')
                        <div class="alert alert-danger" role="alert">
                            <strong>L'email inserita non è valida</strong>
                            <i class="fas fa-times"></i>
                        </div>
                    @enderror

                    @error('username')
                        <div class="alert alert-danger" role="alert">
                            <strong>L'username inserito non è valido o è gia esistente</strong>
                            <i class="fas fa-times"></i>
                        </div>
                    @enderror

                    @error('password')
                        <div class="alert alert-danger" role="alert">
                            <strong>La password deve essere lunga almeno 8 caratteri</strong>
                            <i class="fas fa-times"></i>
                        </div>
                    @enderror

                    @error('password_confirmation')
                        <div class="alert alert-danger" role="alert">
                            <strong>Le password non combaciano</strong>
                            <i class="fas fa-times"></i>
                        </div>
                    @enderror

                    @error('profileimage')
                        <div class="alert alert-danger" role="alert">
                            <strong>L'immagine di profilo non rispetta il formato richiesto</strong>
                            <i class="fas fa-times"></i>
                        </div>
                    @enderror

                    @error('nome')
                        <div class="alert alert-danger" role="alert">
                            <strong>Il nome inserito non rispetta il formato richiesto</strong>
                            <i class="fas fa-times"></i>
                        </div>
                    @enderror

                    @error('cognome')
                        <div class="alert alert-danger" role="alert">
                            <strong>Il cognome inserito non rispetta il formato richiesto</strong>
                            <i class="fas fa-times"></i>
                        </div>
                    @enderror

                    @error('telefono')
                        <div class="alert alert-danger" role="alert">
                            <strong>Il numero di telefono non può contenere più di dieci numeri</strong>
                            <i class="fas fa-times"></i>
                        </div>
                    @enderror

                    <div class="tab">
                        <div class="form-group">
                            <input type="text" class="form-input form-control @error('username') is-invalid @enderror" name="username" id="username" placeholder="Segli un Username">
                        </div>
                    </div>

                    <div class="tab">
                        <div class="form-group">
                            <input type="text" class="form-input form-control @error('email') is-invalid @enderror" name="email" id="email" placeholder="Inserisci la tua Email">
                        </div>
                    </div>

                    <div class="tab">
                        <div class="form-group">
                            <input type="password" class="form-input form-control @error('password') is-invalid @enderror" name="password" id="password" placeholder="Password">
                        </div>
                        <div class="form-group">
                            <input type="password" class="form-input form-control @error('password_confirmation') is-invalid @enderror" name="password_confirmation" id="password-confirm" placeholder="Ripeti la password">
                        </div>
                    </div>

                    <div class="tab">

                        <div class="form-group">
                            <input type="file" accept="image/x-png,image/gif,image/jpeg,image/png,image/jpg" class="form-input form-control @error('profileimage') is-invalid @enderror" name="profileimage" id="profileimage" style="padding-bottom: 40px;">
                        </div>

                        <div class="form-group">
                            <input type="text" class="form-input form-control @error('nome') is-invalid @enderror" name="nome" id="nome" placeholder="Inserisci il tuo Nome">
                        </div>

                        <div class="form-group">
                            <input type="text" class="form-input form-control @error('cognome') is-invalid @enderror" name="cognome" id="cognome" placeholder="Inserisci il tuo Cognome">
                        </div>

                        <div class="form-group">
                            <input type="text" class="form-input form-control @error('telefono') is-invalid @enderror" name="telefono" id="telefono" placeholder="Inserisci il tuo Telefono">
                        </div>
                    </div>

                    <div class="tab">
                        <div class="form-group">

                            <div class="form-group">
                                <label for="agree-term" class="label-agree-term"><span><span></span></span>Proseguendo dichiaro di aver letto e accettato i <a href="#" class="term-service">termini e le condizioni del servizio</a></label>
                            </div>
                        </div>

                    </div>

                    <div style="overflow:auto;">
                        <div style="float:right;">
                            <input type="submit" class="form-input" value="Conferma" id="confirm-register" style="display: none;">
                        </div>
                        <div style="float:right;">
                            <button class="form-submit" type="button" id="nextBtn" onclick="nextPrev(1)">Avanti</button>
                        </div>
                        <div style="float:left;">
                            <button class="form-submit" type="button" id="prevBtn" onclick="nextPrev(-1)">Indietro</button>
                        </div>
                    </div>

                    <!-- Circles which indicates the steps of the form: -->
                    <div style="text-align:center;margin-top:40px;">
                        <span class="step"></span>
                        <span class="step"></span>
                        <span class="step"></span>
                        <span class="step"></span>
                        <span class="step"></span>
                    </div>
                </form>
                <p class="loginhere">
                    Sei già registrato ? <a href="{{route('login')}}" class="loginhere-link">Accedi qui</a>
                </p>
            </div>
        </div>
    </div>
</div>
@endsection
