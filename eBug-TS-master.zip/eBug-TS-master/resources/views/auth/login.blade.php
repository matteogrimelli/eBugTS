@extends('layouts.layout-navbar')

@section('content')
<link href="{{ asset('css/login.css') }}" rel="stylesheet">
<div class="container">
    <div class="row justify-content-center">
        <div>
            <div class="signup-content">
                <form method="POST" action="{{ route('login') }}" class="login-form" enctype="application/x-www-form-urlencoded">
                    @csrf
                    <h2 class="form-title">Accedi</h2>

                    <div class="" style="display: block;">
                        <div class="form-group">
                            <input type="text" class="form-input form-control " name="email" id="email" placeholder="Inserisci la tua Email">
                        </div>
                    </div>

                    <div class="" style="display: block;">
                        <div class="form-group">
                            <input type="password" class="form-input form-control " name="password" id="password" placeholder="Inserisci la tua Password">
                        </div>
                    </div>


                    <div class="form-group row">
                        <div class="w-100 text-center">
                            <button type="submit" class="btn btn-primary">
                                Accedi
                            </button>

                        </div>
                    </div>
                

                </form>
                <p class="signhere">
                    Non sei ancora registrato? <a href="{{route('register')}}" class="signup-link">Registrati Qui</a>
                </p>
            </div>
        </div>
    </div>
</div>
@endsection
