<div>
    <nav class="navbar navbar-light navbar-expand-md" style="background-color: #24292e;padding-right: 12px;padding-top: 12px;padding-bottom: 12px;padding-left: 12px;">
    <div class="container-fluid">
        <a href="{{ route('home') }}"><img src={{asset('storage/images/default/logo.png')}} style="width: 40px;"></a> <a href="{{ route('home') }}" class="navbar-brand" style="color: rgba(255,255,255);padding-left: 10px;">eBug-TS</a>
            <div class="collapse navbar-collapse">
                <ul class="nav navbar-nav ml-auto">
                    @guest
                        <li class="nav-item" role="presentation">
                            <a class="nav-link" href="{{ route('login') }}" style="color: rgba(255,255,255);">Login</a>
                        </li>
                        <li class="nav-item" role="presentation">
                            <a class="nav-link" href="{{ route('register') }}" style="color: rgba(255,255,255);">Register</a>
                        </li>
                    @else
                        <li class="nav-item" role="presentation">
                            <a class="nav-link" href="{{ route('company') }}" style="color: rgba(255,255,255);">My Company</a>
                        </li>
                        <li class="nav-item" role="presentation">
                            <a class="nav-link" href="{{ route('profile') }}" style="color: rgba(255,255,255);">My Profile</a>
                        </li>
                        <li class="nav-item" role="presentation">
                            <a class="nav-link" href="{{ route('logout') }}" style="color: rgba(255,255,255);" onclick="event.preventDefault(); document.getElementById('logout-form').submit();">
                                {{ __('Logout') }}
                            </a>

                            <form id="logout-form" action="{{ route('logout') }}" method="POST" style="display: none;">
                                @csrf
                            </form>
                        </li>
                    @endguest
                </ul>

            </div>
        </div>
    </nav>
</div>
