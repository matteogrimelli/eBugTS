<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, shrink-to-fit=no">
    <title>Home - Brand</title>
    <link rel="stylesheet" href="{{asset('css/bootstrap-welcome.css')}}">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Lato:300,400,700,300italic,400italic,700italic">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Aldrich">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.12.0/css/all.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/ionicons/2.0.1/css/ionicons.min.css">
    <link rel="stylesheet" href="{{asset('css/welcome.css')}}">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/3.5.2/animate.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/aos/2.1.1/aos.css">



</head>

<body>
    @include('navbar')
    <header class="masthead text-white text-center" style="background: url({{asset('storage/images/default/bg-masthead.jpg')}}) no-repeat center center;background-size: cover;height: 535px;">
        <div class="overlay" style="background-color: #24292e;opacity: 0.80;height: 445px;"></div>
        <div class="container" style="margin-top: -173px;">
            <div class="row">
                <div class="col-xl-9 text-center mx-auto" style="margin-top: 30px;background-color: rgb(66,71,76);padding: 28px;">
                    <div class="row">
                        <div class="col" style="margin-top: 0;padding: 5px;">
                            <h1 class="text-center shadow-lg" style="font-size: 28px;color: rgb(25,190,100);font-family: Aldrich, sans-serif;background-color: #24292e;padding: 10px;border: inset rgb(42,86,132) 5px;">Are you a&nbsp;<strong>software developer ?</strong></h1>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col text-center" style="padding: 5px;">
                            <h1 class="text-center shadow-lg" style="font-size: 28px;color: rgb(25,190,100);font-family: Aldrich, sans-serif;background-color: #24292e;padding: 10px;border: inset rgb(42,86,132) 5px;">Do your customers constantly call you on the phone?<br></h1>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col" style="padding: 5px;">
                            <h1 class="text-center shadow" style="color: rgb(144,17,163);font-size: 34px;font-family: Aldrich, sans-serif;background-color: rgb(36,41,46);padding: 10px;border: inset rgb(42,86,132) 5px;">Join E-bug TS to defeat your program bugs through innovative reporting management<br></h1>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </header>
    <section class="bounce animated features-icons bg-light text-center" style="padding-top: 90px;padding-bottom: 90px;">
        <div class="container">
            <div class="row">
                <div class="col-lg-4" data-bs-hover-animate="pulse">
                    <div class="shadow-lg mx-auto features-icons-item mb-5 mb-lg-0 mb-lg-3">
                        <div class="d-flex features-icons-icon"><i class="fas fa-history m-auto" data-bs-hover-animate="pulse" style="color: rgb(25,190,100);"></i></div>
                        <h3>Responsive Feeds</h3>
                        <p class="lead text-center mb-0">History of any actions done by your partners, you can also monitors the progression of bugs segnalations !<br></p>
                    </div>
                </div>
                <div class="col-lg-4" data-bs-hover-animate="pulse">
                    <div class="shadow-lg mx-auto features-icons-item mb-5 mb-lg-0 mb-lg-3">
                        <div class="d-flex features-icons-icon"><i class="fas fa-link m-auto" data-bs-hover-animate="pulse" style="color: rgb(143,17,162);"></i></div>
                        <h3>Smart Cooperation</h3>
                        <p class="lead mb-0">Simple way to join or start a company, you can easily ally developer and customers!<br></p>
                    </div>
                </div>
                <div class="col-lg-4" data-bs-hover-animate="pulse">
                    <div class="shadow-lg mx-auto features-icons-item mb-5 mb-lg-0 mb-lg-3">
                        <div class="d-flex features-icons-icon"><i class="icon ion-ios-chatboxes m-auto" data-bs-hover-animate="pulse" style="color: rgb(36,41,46);"></i></div>
                        <h3>Simple Chat</h3>
                        <p class="lead mb-0">Everyone is able to use our simple chat to write to their contacts,<br>even those who download the ram!<br></p>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <section class="showcase">
        <div class="container-fluid p-0">
            <div class="row no-gutters" data-aos="slide-left" data-aos-offset="100" data-aos-delay="150" data-aos-once="true" style="background-color: rgb(26,26,26);">
                <div class="col-lg-6 order-lg-2 text-white showcase-img" style="background-image: url({{asset('storage/images/default/bg-showcase-1.jpg')}});filter: blur(1px) saturate(200%);"><span></span></div>
                <div class="col-lg-6 my-auto order-lg-1 showcase-text" data-bs-hover-animate="bounce">
                    <h2 style="color: rgb(255,255,255);font-size: 33px;"><strong>Responsive Feeds</strong><br></h2>
                    <p class="lead mb-0" style="color: rgb(162,162,162);font-size: 23px;">Simplified and highlighted history of the actions performed by your partners in the center of the screen so you can monitor everything that happens: reported bugs, bugs in resolution and bugs solved ...</p>
                </div>
            </div>
            <div class="row no-gutters" data-aos="slide-right" data-aos-offset="100" data-aos-delay="150" data-aos-once="true" style="background-color: #2a5684;">
                <div class="col-lg-6 text-white showcase-img" style="filter: blur(1px) saturate(200%);background-image: url({{asset('storage/images/default/bg-showcase-2.jpg')}});"><span></span></div>
                <div class="col-lg-6 my-auto order-lg-1 showcase-text" data-bs-hover-animate="bounce">
                    <h2 style="color: rgb(255,255,255);font-size: 33px;"><strong>Smart Cooperation</strong><br></h2>
                    <p class="lead mb-0" style="color: rgb(162,162,162);font-size: 23px;">Create your account, choose whether to join or create a company and the game is made!<br>Very simple way to join a company: one time code generated by the company and delivered to employees.<br></p>
                </div>
            </div>
            <div class="row no-gutters" data-aos="slide-left" data-aos-offset="100" data-aos-delay="150" data-aos-once="true" style="background-color: #202a32;">
                <div class="col-lg-6 order-lg-2 text-white showcase-img" style="background-image: url({{asset('storage/images/default/bg-showcase-3.jpg')}});filter: blur(1px) saturate(200%);"><span></span></div>
                <div class="col-lg-6 my-auto order-lg-1 showcase-text" data-bs-hover-animate="bounce">
                    <h2 style="color: rgb(255,255,255);font-size: 33px;">Simple chat</h2>
                    <p class="lead mb-0" style="color: rgb(162,162,162);font-size: 23px;">Select a contact and start a quick chat without wasting time !<br>You can communicate with all your partners and also with the most incapable customers beacause they will be able to use our chat ;)</p>
                </div>
            </div>
        </div>
    </section>
    <section class="call-to-action text-white text-center" style="background: url({{asset('storage/images/default/bg-masthead.jpg')}}) no-repeat center center;background-size:cover;"></section>
    <div class="footer-basic">
        @include('footer')
    </div>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.4.1/js/bootstrap.bundle.min.js"></script>
    <script>
        $(document).ready(function(){
            AOS.init({ disable: 'mobile' });
            $('[data-bs-hover-animate]')
                .mouseenter( function(){ var elem = $(this); elem.addClass('animated ' + elem.attr('data-bs-hover-animate')) })
                .mouseleave( function(){ var elem = $(this); elem.removeClass('animated ' + elem.attr('data-bs-hover-animate')) });
        });
    </script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/aos/2.1.1/aos.js"></script>
</body>

</html>
