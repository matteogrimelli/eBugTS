@extends('layouts.layout')

@section('content')
        <div class="container-fluid">
            <h3 class="text-dark mb-4" style="font-size: 36px;">{{$software->nome}}</h3>
            <div class="row mb-3">
                <div class="col-lg-4">
                    <div class="card mb-3">
                        <div class="card-body text-center shadow"><img class="rounded-circle mb-3 mt-4" src={{asset($software->urlMedia)}} width="160" height="160" style="width: 150px;height: 150px;border: 3px solid rgb(33,37,41);">
                            <div class="mb-3"></div>
                        </div>
                    </div><a href="/bugs/new?software={{urlencode($software->nome)}}"><button class="btn btn-primary" type="button" style="width: 100%;height: 55px;background-color: rgb(36,41,46);font-size: 20px;"><i class="fa fa-warning" style="font-size: 25px;margin-right: 17px;color: rgb(255,214,0);"></i>SEGNALA BUG</button></a></div>
                <div class="col-lg-8">
                    <div class="row">
                        <div class="col">
                            <div class="card shadow mb-3">
                                <div class="card-header py-3" style="background-color: rgb(255,255,255);">
                                    <p class="text-primary m-0 font-weight-bold" style="font-size: 20px;color: rgb(255,255,255);">{{$software->aziendaSviluppatrice}}</p>
                                </div>
                            </div>
                            <div class="card shadow">
                                <div class="card-body">
                                    <form><label for="address" style="font-size: 24px;"><strong>Descrizione</strong></label><textarea class="form-control" style="width: 100%;height: 200px;" disabled>{{$software->descrizione}}</textarea></form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
@endsection
