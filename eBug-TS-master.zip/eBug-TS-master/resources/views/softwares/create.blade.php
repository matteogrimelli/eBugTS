@extends('layouts.layout-navbar')

@section('content')

<link href="{{ asset('css/software-creation.css') }}" rel="stylesheet">
<script src="{{ asset('js/software-creation.js') }}" defer></script>

<div class="register" style="background-color: rgb(235,235,235);">
    <div class="form-container">
        <form method="post" action="/software/new">
            @csrf
            <h2 class="text-center" style="font-size: 28px;"><strong>Add&nbsp;</strong>a software</h2>
            <div class="form-group"><input class="form-control" name="nome" type="text" placeholder="Software Name"></div>
            <div class="form-group"><textarea class="form-control" name="descrizione" placeholder="Description"></textarea></div>
            <div class="form-group" id="comp-select" style="height: auto;background-color: #ebebeb;max-height: 250px;">
                <select name="nomeAziendaClienti" size="{{count($aziendeClienti)+1}}" id="ul-company" class="custom-select">
                    @foreach ($aziendeClienti as $company)
                        <option value="{{$company->nome}}" class="list-company" style="margin-top: 6px;margin-right: 12px;margin-bottom: 6px;margin-left: 12px;padding: 0px;padding-top: 12px;padding-right: 6px;padding-bottom: 12px;padding-left: 12px;"><img src="{{asset(\App\Media::where('IDMedia', $company->idMedia)->first()->urlMedia)}}" style="height: 50px;width: 50px;margin-right: 55px;"><a>{{$company->nome}}</a></option>
                    @endforeach
                </select>
            </div>
            <div class="form-group"><button class="btn btn-primary btn-block" type="submit" style="background-color: #24292e;">CONFERMA</button></div>
        </form>
    </div>
</div>
<div class="footer-basic">
    @include('footer')
</div>
@endsection
