@extends('layouts.layout')

@section('content')
    <div id="dashboard">
        <div id="news">
            <div class="card mx-auto border-0">
                <div class="card-body bg-light">
                    <ul class="list-group" style="align-items:center">
                        @foreach (array_reverse($updates) as $update)
                            <li class="list-group-item mb-2 border" style="width: 700px;">

                                <div class="media" style="overflow:visible;">
                                    <div><img class="mr-3" src="{{asset($update->urlMedia)}}" style="width: 25px; height:25px;"></div>
                                    <div class="media-body" style="overflow:visible;">
                                        <div class="row">
                                            <div class="col-md-12">
                                                <p><a href="/profile/{{$update['username']}}">{{$update['username']}}:</a> {{$update->messaggio}} on <a href="/company/{{$update['softwareName']}}">{{$update['softwareName']}}</a><br><small class="text-muted">{{ date($update->timestampAggiornamentoBug) }} </small></p>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </li>
                        @endforeach
                    </ul>
                </div>
            </div>
        </div>
    </div>
@endsection
