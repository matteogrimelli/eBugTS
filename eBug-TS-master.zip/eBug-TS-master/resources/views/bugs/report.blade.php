@extends('layouts.layout')
@section('content')

<link rel="stylesheet" href="{{asset('css/bug-report.css')}}">
<script src="{{asset('js/bug-report.js')}}" defer></script>
<div class="report" style="background-color: rgb(229,225,225);">
    <div class="form-container">
        <form method="post">
            @csrf
            <input type="text" id="input-software" name="softwarename" value="{{$softwares[0]->nome ?? ''}}" hidden>
            <h2 class="text-center"><strong>Report</strong> a bug</h2>
            <div class="form-group">
                <select name="urgenza" id="priority" class="form-control" >
                        <optgroup label="Choose Prority">
                            <option value="0" id="low">Bassa</option>
                            <option value="1" id="med">Media</option>
                            <option value="2" id="hig">Alta</option>
                        </optgroup>
                </select>
            </div>
            <div class="form-group"><textarea class="form-control" name="descrizione" id="description" placeholder="Issue description"></textarea></div>
            <div class="form-group">
                <div class="selectbox">
                    <div role="tablist" id="accordion-2" class="accordion accordion-select">
                        <div class="card">
                            <div class="card-header" role="tab">
                                <h5 class="mb-0"><a data-toggle="collapse" aria-expanded="true" aria-controls="accordion-2 .item-1" href="#accordion-2 .item-1" class="selectbox-title" style="height: 25px;">Select Software<i class="fa fa-arrow-left "></i></a></h5>
                            </div>
                            <div class="collapse show item-1" role="tabpanel" data-parent="#accordion-2">
                                <div class="card-body">
                                    <ul>
                                        @foreach ($softwares as $software)
                                            <li><a azienda="{{$software->nome}}" class="selectbox-link">{{$software->nome}}<span>{{$software->AziendaSviluppatrice}}</span></a></li>
                                        @endforeach
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="form-group"><button class="btn btn-primary btn-block" type="submit" style="background-color: #24292e;">REPORT</button></div>
        </form>
    </div>
</div>
@endsection
