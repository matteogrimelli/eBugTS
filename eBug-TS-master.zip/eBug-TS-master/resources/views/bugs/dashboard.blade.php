@extends('layouts.layout')
@section('content')
<link rel="stylesheet" href="{{ asset('css/bug-dashboard.css') }}">
<div class="modal fade modalBg mt-5" id="modalA" tabindex="-1" role="dialog" aria-labelledby="modalALabel">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header" style="background-color: rgb(36,41,46); color: white;">
                <h4 class="modal-title" id="modalALabel">Inserisci commento</h4>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true"
                        style="color: white; font-size: 30px;">&times;</span></button>
            </div>
            <form method="POST" action="{{ route('add_update', ['software_name'=>$bug->software_name, 'relative_id'=>$bug->relative_id]) }}">
                @csrf
            <div class="modal-body">
                <textarea name="descrizione" id="txtA" cols="30" rows="10" class="form-control ModalTa"
                    placeholder="Commenta qui..."></textarea>
            </div>
            <div class="modal-footer" style="background-color: rgb(218,218,218);">
                <button type="button" class="btn btn-default btnClose" data-dismiss="modal">Chiudi</button>
                <button type="submit" class="btn btn-primary btbSave">Conferma</button>
            </div>
            </form>
        </div>
    </div>
</div>
<div class="modal fade modalBg mt-5" id="modalS" tabindex="-1" role="dialog" aria-labelledby="modalSLabel">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header" style="background-color: rgb(36,41,46); color: white;">
                <h4 class="modal-title" id="modalSLabel">Modifica stato</h4>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true"
                        style="color: white; font-size: 30px;">&times;</span></button>
            </div>
            <form method="POST" action="{{ route('set_stato', ['software_name'=>$bug->software_name, 'relative_id'=>$bug->relative_id]) }}">
                @csrf
                <div class="modal-body">
                    <div class="form-group" style="margin-bottom: 100px;">
                        <select name="stato" id="priority" class="form-control">
                            <optgroup label="Seleziona stato bug"
                                style="background-color:rgb(36,41,46); color: white; font-size: 18px;">
                                <option value="0" id="low">Aperto</option>
                                <option value="1" id="med">In attesa</option>
                                <option value="2" id="hig">Risolto</option>
                            </optgroup>
                        </select>
                    </div>
                </div>
                <div class="modal-footer" style="background-color: rgb(218,218,218);">
                    <button type="button" class="btn btn-default btnClose" data-dismiss="modal">Chiudi</button>
                    <button type="submit" class="btn btn-primary btbSave">Conferma</button>
                </div>
            </form>
        </div>
    </div>
</div>
<div class="modal fade modalBg mt-5" id="modalP" tabindex="-1" role="dialog" aria-labelledby="modalPLabel">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header" style="background-color: rgb(36,41,46); color: white;">
                <h4 class="modal-title" id="modalPLabel">Modifica priorità</h4>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true"
                        style="color: white; font-size: 30px;">&times;</span></button>
            </div>
            <form method="POST" action="{{ route('set_urgenza', ['software_name'=>$bug->software_name, 'relative_id'=>$bug->relative_id]) }}">
                @csrf
            <div class="modal-body">
                <div class="form-group" style="margin-bottom: 100px;">
                    <select name="urgenza" id="priority" class="form-control">
                        <optgroup label="Seleziona priorità Bug"
                            style="background-color:rgb(36,41,46); color: white; font-size: 18px;">
                            <option value="0" id="low">Bassa</option>
                            <option value="1" id="med">Media</option>
                            <option value="2" id="hig">Alta</option>
                        </optgroup>
                    </select>
                </div>
            </div>
            <div class="modal-footer" style="background-color: rgb(218,218,218);">
                <button type="button" class="btn btn-default btnClose" data-dismiss="modal">Chiudi</button>
                <button type="submit" class="btn btn-primary btbSave">Conferma</button>
            </div>
        </form>
        </div>
    </div>
</div>
<div class="container mb-2 border"
    style="padding: 20px;background-color: #24292e;padding-right: 35px;padding-left: 35px;">
    <div class="row" style="color: rgb(242,242,242);">
        <div class="col" style="padding: 15px;background-color: rgb(40,40,40);border: 3px solid white;margin: 5px;">
            <h1 style="color: rgb(231,231,231);padding-bottom: 20px;">Bug
                #{{ str_pad($bug->relative_id, 4, 0, STR_PAD_LEFT) }}</h1>
            <div style="background-color: rgb(40,40,40);">
                <p style="color: red;font-size: 30px;padding-bottom: 20px;">Stato: <span>{{ $bug->stato }}</span></p>
                <p style="color: rgb(255,255,0);font-size: 20px;">Priorità: <span>{{ $bug->urgenza }}</span></p>
            </div>
        </div>
        <div class="col"
            style="color: rgb(36,41,46);text-align: center;padding: 15px;background-color: rgb(40,40,40);border: solid 3px white;margin: 5px;">
            <h1 style="color: rgb(231,231,231);">{{ $bug->software_name }}</h1>
            <p style="color: rgb(150,150,150);">By: <span>{{ $bug->aziendaDev }}</span></p>
        </div>
    </div>
</div>
<div>
    <div>
        <div class="card mx-auto" style="background-color: #dadada;border: solid 2px;">
            <form class="mb-2border" style="margin-top: 0px;padding: 20px;padding-left: 15px;padding-right: 15px;">
                <div class="form-group" style="margin: 10px;margin-bottom: 0px;">
                    <div class="input-group" style="margin: 5px;">
                        <div class="form-row btnrow" style="width: 100%;height: 50px;">
                            <div class="col"><button class="btn btn-primary w-100 h-100" type="button"
                                    style="background-color: rgb(36,41,46);font-size: 20px;" data-toggle="modal"
                                    data-target="#modalA">Inserisci aggiornamento</button></div>
                            <div class="col"><button class="btn btn-primary w-100 h-100" type="button"
                                    style="background-color: rgb(150,0,0);font-size: 20px;" data-toggle="modal"
                                    data-target="#modalS">Modifica stato</button></div>
                            <div class="col"><button class="btn btn-primary w-100 h-100" type="button"
                                    style="background-color: rgb(150,125,0);font-size: 20px;" data-toggle="modal"
                                    data-target="#modalP">Modifica priorità</button></div>
                        </div>
                    </div>
                </div>
            </form>
            <div class="card-body" style="background-color: #f2f2f2;">
                <ul class="list-group">
                    @foreach($updates as $update)
                        <li class="list-group-item mb-2 border">
                            <div class="media" style="overflow:visible;">
                                <div><img class="mr-3" src="{{ asset($update->urlMedia) }}"
                                        style="width: 25px; height:25px;"></div>
                                <div class="media-body" style="overflow:visible;">
                                    <div class="row">
                                        <div class="col-md-12">
                                            <p><a
                                                    href="/profile/{{ $update['username'] }}">{{ $update->username }}</a><small
                                                    class="text-muted"
                                                    style="position: absolute;right: 5%;">{{ $update->created_at }}</small>
                                            </p>
                                            <div>
                                                <p>{{ $update->messaggio }}<br></p>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </li>
                    @endforeach
                </ul>
            </div>
        </div>
    </div>
</div>

@endsection
