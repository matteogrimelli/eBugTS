window.Vue = require('vue');
var xss = require("xss");

Vue.component('chat-form', require('./components/ChatForm.vue').default);

const app = new Vue({

    el: '#app',

    data: {
        messages: {}
    },

    created() {
        this.fetchMessages();

        Echo.private('chat_'+username_)
        .listen('MessageSent', (e) => {
            //console.log('Arrivato!'),
            mittente = e.user;
            testo = e.message['testo'];
            timestamp = e.message['timestamp'];

            $(`[dest='${mittente}']`).append(
                `<div class="media w-50 mb-3">
                    <div class="media-body ml-3">
                        <div class="bg-light rounded py-2 px-3 mb-2">
                            <p class="text-small mb-0 text-muted" style="word-wrap: break-word; max-width:200px"> ${testo} </p>
                        </div>
                        <p class="small text-muted"> ${timestamp} </p>
                    </div>
                </div>`);
            document.getElementById('append-message').scrollTop = 999999999;
        });

    },

    methods: {
            fetchMessages() {
                axios.post('/chat/receive/messages', {

              }).then(response => {
                $.each(response.data, function( username, messages ) {
                    // Key -> username
                    // value -> message list
                    
                    app.messages[username] = [];
                    
                    chat = `<div id="append-message" dest="${username}" class="px-4 py-5 chat-box bg-white" style="overflow-y:scroll; max-height: 500px; width: 500px">`
                    

                    $.each(messages, function( index, messaggio ) {
                        /*console.log('mittente: ', username)
                        console.log('index: ', index);
                        console.log('orario: ', messaggio['orario']);
                        console.log('testo: ', messaggio['testo']);*/
                        app.messages[username].push(messaggio);

                        if(messaggio['ricevuto'] == true)
                            chat+= `<div class="media w-50 mb-3">
                                        <div class="media-body ml-3">
                                            <div class="bg-light rounded py-2 px-3 mb-2">
                                                <p class="text-small mb-0 text-muted" style="word-wrap: break-word; max-width:200px"> ${messaggio['testo']} </p>
                                            </div>
                                            <p class="small text-muted"> ${messaggio['orario']} </p>
                                        </div>
                                    </div>`;
                        else
                            chat+= `<div class="media w-50 ml-auto mb-3">
                                        <div class="media-body">
                                            <div class="bg-primary rounded py-2 px-3 mb-2">
                                                <p class="text-small mb-0 text-white" style="word-wrap: break-word; max-width:200px"> ${messaggio['testo']} </p>
                                            </div>
                                            <p class="small text-muted"> ${messaggio['orario']} </p>
                                        </div>
                                    </div>`;

                    });
                    $('#messages-parent').children(`[username='${username}']`).prepend(chat);
                    document.getElementById('append-message').scrollTop = 999999999;
                });
            });
        },


        addMessage(message) {
            destinatario = message['destinatario'];
            messaggio = xss(message['message']);
            
            t = new Date(Date.now());
            anno = t.getFullYear();
            mese = (t.getMonth()+1).toString().padStart(2, 0);
            giorno = t.getDate().toString().padStart(2, 0);
            ora = t.getHours().toString().padStart(2, 0);
            minuti = t.getMinutes().toString().padStart(2, 0);
            secondi = t.getSeconds().toString().padStart(2, 0);
            data = `${anno}-${mese}-${giorno} ${ora}:${minuti}:${secondi}`;

            axios.post('/chat/send', message).then(response => {
                //console.log(response.data);
            });

            $(`[dest='${destinatario}']`).append(
                `<div class="media w-50 ml-auto mb-3">
                    <div class="media-body">
                        <div class="bg-primary rounded py-2 px-3 mb-2">
                            <p class="text-small mb-0 text-white style="word-wrap: break-word; max-width:200px"> ${messaggio} </p>
                        </div>
                        <p class="small text-muted"> ${data} </p>
                    </div>
                </div>`);

            document.getElementById('append-message').scrollTop = 999999999;
        }
    }
});

$(document).ready(function(){
    $("#chat-show").click(function(){
        $("#chat").show();
        $("#chat-show").hide();
    });

    $("#chat-hide").click(function(){
        $("#chat").hide();
        $("#chat-show").show();
    });

    $(document).on('click', '.chat-person', function(){

        $username_ = $(this).attr("username");
        var selector = "[username=\"" + $username_ + "\"]";

        if( $("#messages-list").find( selector ).length == 1){
            
            $("#chat-list").hide();
            $("#messages-hide").show();
            $("#messages-list").show();
            $("#messages-list").find( selector ).show();

        }

    });

    $("#messages-hide").click(function(){
        $("#chat-list").show();
        $("#messages-hide").hide();

        $("#messages-list").hide();
        $(".messages-person").hide();

    });
});