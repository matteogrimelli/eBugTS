<template>
    <div class="input-group">
        <input id="btn-input" type="text" name="testo" class="form-control rounded-0 border-0 py-4 bg-light"  placeholder="Type a message" v-model="newMessage" @keyup.enter="sendMessage">
        <div class="input-group-append">
            <button id="btn-chat" class="btn btn-link" @click="sendMessage">
                <i class="fa fa-paper-plane">&nbsp;</i>
            </button>
        </div>
    </div>

</template>

<script>
    export default {
        props: ['destinatario'],

        data() {
            return {
                newMessage: ''
            }
        },

        methods: {
            sendMessage() {
                //console.log(this.newMessage),
                //console.log(this.destinatario),
                this.$emit('messagesent', {
                    message: this.newMessage,
                    destinatario: this.destinatario,
                });

                this.newMessage = ''
            }
        }    
    }
</script>