$(document).ready(function(){

    $('#add-dipendente').click(function(){
        $.ajax({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            },
            url: "/company/invite_dipendente",
            method: 'POST'
        }).done(function(data) {
            $('#url-popup').val(data);
        });
    });

});