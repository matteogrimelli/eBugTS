<?php

namespace App;

use Illuminate\Contracts\Auth\MustVerifyEmail;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;

class Dipendenti extends Authenticatable
{
    use Notifiable;

    # Overrides deafult table name, which by default is 'Dipendentis', s would be added as a plural
    protected $table = 'dipendenti';

    # Overrides default primary key name, which by default is 'id'
    protected $primaryKey = 'IDDipendente';

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'username',
        'nome',
        'cognome',
        'email',
        'password',
        'telefono',
        'livAzienda',
        'idMedia',
        'idAzienda'
    ];

    /**
     * The attributes that are NOT mass assignable.
     *
     * @var array
     */
    protected $guarded = [
        'IDDipendente',
        'email_verified_at',
        'remember_token',
        'created_at',
        'updated_at'
    ];

    /**
     * The attributes that should be hidden for arrays.
     *
     * @var array
     */
    protected $hidden = [
        'password',
        'remember_token',
    ];

    /**
     * The attributes that should be cast to native types.
     *
     * @var array
     */
    protected $casts = [
        'email_verified_at' => 'datetime',
    ];
}
