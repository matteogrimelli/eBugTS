<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Media extends Model
{
    # Overrides deafult table name, which by default is 'Medias', s would be added as a plural
    protected $table = 'media';

    # Overrides default primary key name, which by default is 'id'
    protected $primaryKey = 'IDMedia';

    /**
     * The attributes that are NOT mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'urlMedia'
    ];

    /**
     * The attributes that are NOT mass assignable.
     *
     * @var array
     */
    protected $guarded = [
        'IDMedia'
    ];

}
