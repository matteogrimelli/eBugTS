<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Bugs extends Model
{
    # Overrides deafult table name, which by default is 'Bugses', s would be added as a plural
    protected $table = 'bugs';

    # Overrides default primary key name, which by default is 'id'
    protected $primaryKey = 'IDBug';

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'urgenza',
        'stato',
        'timestampCreazioneBug',
        'idSegnalatore',
        'idSoftware',
        'relative_id'
    ];

    /**
     * The attributes that are NOT mass assignable.
     *
     * @var array
     */
    protected $guarded = [
        'IDBug', 'created_at', 'updated_at'
    ];

}
