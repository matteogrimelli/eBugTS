<?php

namespace App\Events;


use App\messaggi;
use App\Dipendenti;
use Illuminate\Broadcasting\Channel;
use Illuminate\Queue\SerializesModels;
use Illuminate\Broadcasting\PrivateChannel;
use Illuminate\Broadcasting\PresenceChannel;
use Illuminate\Foundation\Events\Dispatchable;
use Illuminate\Broadcasting\InteractsWithSockets;
use Illuminate\Contracts\Broadcasting\ShouldBroadcast;
use Illuminate\Support\Facades\Auth;

class MessageSent implements ShouldBroadcast
{
    use Dispatchable, InteractsWithSockets, SerializesModels;

    /**
     * Destinatario
     *
     * @var Dipendenti
     */
    public $dest;

    /**
     * User that sent the message
     *
     * @var Dipendenti
     */
    public $user;

    /**
     * Message details
     *
     * @var messaggi
     */
    public $message;

    /**
     * Create a new event instance.
     *
     * @return void
     */
    public function __construct(Dipendenti $dest, Dipendenti $user, messaggi $message)
    {   
        $this->dest = $dest->username;
        $this->user = $user->username;
        $this->message['testo'] = $message->testo;
        $this->message['timestamp'] = $message->created_at->toDateTimeString();
    }

    /**
     * Get the channels the event should broadcast on.
     *
     * @return Channel|array
     */
    public function broadcastOn()
    {
        return new PrivateChannel('chat_'.$this->dest);
    }
}
