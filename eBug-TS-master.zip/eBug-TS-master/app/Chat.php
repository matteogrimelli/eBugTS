<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Chat extends Model
{
    # Overrides deafult table name
    protected $table = 'chat';

    # Overrides default primary key name, which by default is 'id'
    protected $primaryKey = 'IDChat';

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'idProprietario',
        'idDestinatario'
    ];

    /**
     * The attributes that are NOT mass assignable.
     *
     * @var array
     */
    protected $guarded = [
        'IDChat', 'created_at', 'updated_at'
    ];

}
