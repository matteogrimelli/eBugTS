<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Aziende extends Model
{
    # Overrides deafult table name, which by default is 'Aziendes', s would be added as a plural
    protected $table = 'aziende';

    # Overrides default primary key name, which by default is 'id'
    protected $primaryKey = 'IDAzienda';

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'email',
        'nome',
        'telefono',
        'tipoAzienda',
        'localita',
        'idMedia'
    ];

    /**
     * The attributes that are NOT mass assignable.
     *
     * @var array
     */
    protected $guarded = [
        'IDAzienda', 'created_at', 'updated_at'
    ];

}
