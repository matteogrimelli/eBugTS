<?php

namespace App\Http\Controllers\Bugs;

use App\aggiornamentiBug;
use App\Bugs;
use App\Dipendenti;
use App\Http\Controllers\Company\AziendeController;
use App\Http\Controllers\Controller;
use App\Http\Controllers\Softwares\SoftwareController;
use App\Media;
use App\Softwares;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Validator;

class BugsController extends Controller
{

    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }


    /**
     * Show the specified bug's dashboard
     *
     */
    public function show_bug($software, $relative_id)
    {
        # Check if user has a company
        if( ! AziendeController::hasAzienda() ){
            return redirect('nocompany');
        }

        $software_name = urldecode($software);
        $relative_id = urldecode($relative_id);
        $software = SoftwareController::getSoftwareByName($software_name);
        $software_id = $software->IDSoftware;
        $aziendaDev = $software->aziendaSviluppatrice;

        $bug = Bugs::where('idSoftware', $software_id)->where('relative_id', $relative_id)->get()->first();
        
        if(empty($bug)) return redirect(404);

        $bug->software_name = $software_name;
        $bug->aziendaDev = $aziendaDev;
        $bug->stato = $bug->stato == 0 ? 'Aperto' : ($bug->stato == 1 ? 'In attesa' : 'Risolto');
        $bug->urgenza = $bug->urgenza == 0 ? 'Bassa' : ($bug->urgenza == 1 ? 'Media' : 'Alta');

        $aggiornamentiBug = aggiornamentiBug::where('idBug', $bug->IDBug)->orderBy('created_at', 'desc')->get();
        $updates = [];

        foreach ($aggiornamentiBug as $update) {
            $dipendenti = Dipendenti::select('username', 'idMedia')
                            ->where('IDDipendente', $update->idCreatore)
                            ->first();

            $update->username = $dipendenti->username;
            $update->urlMedia = Media::where('IDMedia', $dipendenti->idMedia)->first()->urlMedia;

            array_push($updates, $update);
        }

        return view('bugs.dashboard')->with('updates', $updates)->with('bug', $bug);
    }

    public function add_update(Request $request, $software_name, $relative_id) {
        # Validate user input
        $this->validator_update($request->all())->validate();
        
        $software = SoftwareController::getSoftwareByName($software_name);
        $software_id = $software->IDSoftware;
        $bug = Bugs::where('idSoftware', $software_id)->where('relative_id', $relative_id)->get()->first();
        if(empty($bug)) return redirect(503);

        aggiornamentiBug::create([
            'messaggio' => $request->descrizione,
            'idCreatore' => Auth::user()->IDDipendente,
            'idBug' => $bug->IDBug
        ]);

        return redirect("/company/$software_name/bugs/$relative_id");

    }

    public function set_urgenza(Request $request, $software_name, $relative_id) {

        # Validate user input
        $this->validator_urgenza($request->all())->validate();

        $software = SoftwareController::getSoftwareByName($software_name);
        $software_id = $software->IDSoftware;
        $bug = Bugs::where('idSoftware', $software_id)->where('relative_id', $relative_id)->get()->first();
        if(empty($bug)) return redirect(503);

        # Update bug's urgenza
        $bug = Bugs::find( $bug->IDBug );
        $bug->urgenza = $request->urgenza;
        $bug->save();

        $urgenza = $bug->urgenza == 0 ? 'Bassa' : ($bug->urgenza == 1 ? 'Media' : 'Alta');

        aggiornamentiBug::create([
            'messaggio' => 'Urgenza aggiornata a '.$urgenza,
            'idCreatore' => Auth::user()->IDDipendente,
            'idBug' => $bug->IDBug
        ]);

        return redirect("/company/$software_name/bugs/$relative_id");
    }

    public function set_stato(Request $request, $software_name, $relative_id) {

        # Validate user input
        $this->validator_stato($request->all())->validate();
        
        $software = SoftwareController::getSoftwareByName($software_name);
        $software_id = $software->IDSoftware;
        $bug = Bugs::where('idSoftware', $software_id)->where('relative_id', $relative_id)->get()->first();
        if(empty($bug)) return redirect(503);

        # Update bug's stato
        $bug = Bugs::find( $bug->IDBug );
        $bug->stato = $request->stato;
        $bug->save();

        $stato = $bug->stato == 0 ? 'Aperto' : ($bug->stato == 1 ? 'In attesa' : 'Risolto');

        aggiornamentiBug::create([
            'messaggio' => 'Stato aggiornato a '.$stato,
            'idCreatore' => Auth::user()->IDDipendente,
            'idBug' => $bug->IDBug
        ]);

        return redirect("/company/$software_name/bugs/$relative_id");
    }

    /**
     * Get a validator for an incoming request.
     *
     * @param  array  $data
     * @return \Illuminate\Contracts\Validation\Validator
     */
    protected function validator_update(array $data)
    {
        return Validator::make($data, [
            'descrizione' => ['required', 'string', 'min:1']
        ]);
    }

    /**
     * Get a validator for an incoming request.
     *
     * @param  array  $data
     * @return \Illuminate\Contracts\Validation\Validator
     */
    protected function validator_stato(array $data)
    {
        return Validator::make($data, [
            'stato' => ['required', 'int']
        ]);
    }

    /**
     * Get a validator for an incoming request.
     *
     * @param  array  $data
     * @return \Illuminate\Contracts\Validation\Validator
     */
    protected function validator_urgenza(array $data)
    {
        return Validator::make($data, [
            'urgenza' => ['required', 'int']
        ]);
    }


}
