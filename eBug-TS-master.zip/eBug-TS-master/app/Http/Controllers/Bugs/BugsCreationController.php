<?php
namespace App\Http\Controllers\Bugs;

use App\aggiornamentiBug;
use App\Aziende;
use App\Http\Controllers\Controller;
use App\Softwares;
use App\Bugs;
use App\Http\Controllers\Company\AziendeController;
use Illuminate\Support\Facades\Validator;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class BugsCreationController extends Controller
{
    /*
    |--------------------------------------------------------------------------
    | Bugs Creation Controller
    |--------------------------------------------------------------------------
    |
    | This controller handles the bugs creation.
    |
    */

    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }

    /**
     * Show the view for the bugs report
     * -- only if the user has a company --
     *
     */
    public function show()
    {
        # Check if user has a company
        if( ! AziendeController::hasAzienda() ){
            return redirect('nocompany');
        }

        return view('bugs.report');

    }

    /**
     * Post Endpoint for bugs creation
     * Handles the bugs' creation requests
     *
     */
    public function report_bug(Request $request)
    {
        # Check if user has a company
        if(! AziendeController::hasAzienda()){
            abort(403);
        }

        # Validate user input
        $this->validator($request->all())->validate();

        $idSoftware = Softwares::where('nome', $request->softwarename)->get()->first()->IDSoftware;
        
        $bugs_software = Bugs::where('idSoftware', $idSoftware)->get();

        $relative_id = count($bugs_software) > 0 ? $bugs_software->count() : 0;

        $bug = $this->create(array_merge(
            ['relative_id' => $relative_id],
            ['urgenza' => $request->urgenza],
            ['stato' => 0],
            ['idSegnalatore' => Auth::user()->IDDipendente],
            ['idSoftware' => $idSoftware]
        ));

        aggiornamentiBug::create([
            'messaggio' => $request->descrizione,
            'idCreatore' => Auth::user()->IDDipendente,
            'idBug' => $bug->IDBug
        ]);

        return redirect('/home');

    }

    /**
     * Get a validator for an incoming bug creation request.
     *
     * @param  array  $data
     * @return \Illuminate\Contracts\Validation\Validator
     */
    protected function validator(array $data)
    {
        return Validator::make($data, [
            'urgenza' => ['required', 'int'],
            'softwarename' => ['required', 'string']
        ]);
    }

    /**
     * Create a new instance after a valid bug creation.
     *
     * @param  array  $data
     * @return \App\Bugs
     */
    protected function create(array $data)
    {
        return Bugs::create([
            'relative_id' => $data['relative_id'],
            'urgenza' => $data['urgenza'],
            'stato' => $data['stato'],
            'idSegnalatore' => $data['idSegnalatore'],
            'idSoftware' => $data['idSoftware'],
        ]);
    }

}
