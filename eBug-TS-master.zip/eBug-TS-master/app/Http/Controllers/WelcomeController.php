<?php

namespace App\Http\Controllers;

use Illuminate\Support\Facades\Auth;

class WelcomeController extends Controller
{
    /**
     * Return welcome or home depending on which the user is authenticated or not
     *
     */
    public function index()
    {
        if(Auth::check())
            return redirect('home');
        else
            return view('welcome');
    }


}
