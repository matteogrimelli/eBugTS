<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Dipendenti;
use App\Media;
use Illuminate\Support\Facades\Auth;

class ProfileController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }

    /**
     * Show the user profile of the given username
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function index_id($username)
    {
        # Query the profiles
        $query = Dipendenti::where('username', $username);
        $profile = $query->first();

        # Check if profile with given username exists
        if(! $query->exists() )
            abort(404, 'Profile not found');

        # Query the profile image
        $img_url = Media::where('IDMedia', $profile->idMedia)->first()->urlMedia;

        return view('profile')
            ->with('profile', $profile)
            ->with('img_url', $img_url);
    }

    /**
     * Show the user profile of the given username
     *
     */
    public function index()
    {
        $username = Auth::user()->username;

        return redirect()->route('profile_id', [$username]);
    }


}
