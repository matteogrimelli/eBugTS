<?php

namespace App\Http\Controllers\Auth;

use App\Http\Controllers\Controller;
use App\Providers\RouteServiceProvider;
use App\Dipendenti;
use App\Media;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Validator;
use Illuminate\Auth\Events\Registered;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class RegisterController extends Controller
{
    /*
    |--------------------------------------------------------------------------
    | Register Controller
    |--------------------------------------------------------------------------
    |
    | This controller handles the registration of new users as well as their
    | validation and creation.
    |
    */

    /**
     * Where to redirect users after registration.
     *
     * @var string
     */
    protected $redirectTo = RouteServiceProvider::HOME;

    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('guest');
    }

    /**
     * Handle a registration request for the application.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\RedirectResponse
    */
    public function register(Request $request)
    {
        # Validate user input
        $this->validator($request->all())->validate();

        # Create the Media uploaded
        if($request->hasFile('profileimage')) {

            # Generate unique filename and store the image in /public/storage/images/
            $path = $request->file('profileimage')->store('public/images');
            $path = str_replace('public', 'storage', $path);

            # Save the media into the DB and get its id
            $IDMedia = Media::create([
                'urlMedia' => $path
            ])->IDMedia;
        }
        else {
            # Default avatars
            # 1 - male 1
            # 2 - male 2
            # 3 - female 1
            # 4 - female 2
            $IDMedia = 1;
        }

        # Register and create the user
        event(new Registered($user = $this->create( array_merge($request->all(), ['idMedia' => $IDMedia]) )));

        # Login the user
        Auth::guard()->login($user);

        # Redirect the user
        return redirect($this->redirectPath());
    }

    /**
     * Get a validator for an incoming registration request.
     *
     * @param  array  $data
     * @return \Illuminate\Contracts\Validation\Validator
     */
    protected function validator(array $data)
    {
        return Validator::make($data, [
            'username' => ['required', 'string', 'max:21', 'unique:dipendenti'],
            'nome' => ['required', 'string', 'max:60'],
            'cognome' => ['required', 'string', 'max:60'],
            'email' => ['required', 'string', 'email', 'max:255', 'unique:dipendenti'],
            'telefono' => ['nullable', 'string', 'max:10'],
            'password' => ['required', 'min:8'],
            'password_confirmation' => ['required', 'same:password']
        ]);
    }

    /**
     * Create a new user instance after a valid registration.
     *
     * @param  array  $data
     * @return \App\Dipendenti
     */
    protected function create(array $data)
    {
        return Dipendenti::create([
            'username' => $data['username'],
            'nome' => $data['nome'],
            'cognome' => $data['cognome'],
            'email' => $data['email'],
            'password' => Hash::make($data['password']),
            'telefono' => $data['telefono'],
            'idMedia' => $data['idMedia']
        ]);
    }
    
    /**
     * Get the post register / login redirect path.
     *
     * @return string
     */
    public function redirectPath()
    {
        if (method_exists($this, 'redirectTo')) {
            return $this->redirectTo();
        }

        return property_exists($this, 'redirectTo') ? $this->redirectTo : '/home';
    }

    /**
     * Show the application registration form.
     *
     * @return \Illuminate\Http\Response
     */
    public function showRegistrationForm()
    {
        return view('auth.register');
    }

}
