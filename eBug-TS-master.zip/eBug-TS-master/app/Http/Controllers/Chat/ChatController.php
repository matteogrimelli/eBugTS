<?php
namespace App\Http\Controllers\Chat;

use App\Http\Controllers\Company\AziendeController;
use App\Aziende;
use App\Http\Controllers\Controller;
use App\Events\MessageSent;
use App\Media;
use App\messaggi;
use App\Chat;
use App\Dipendenti;
use App\collaborazioni;
use App\Softwares;
use Illuminate\Support\Facades\Validator;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class ChatController extends Controller
{
    /*
    |--------------------------------------------------------------------------
    | Chat Controller
    |--------------------------------------------------------------------------
    |
    | This controller handles the chat and messages.
    |
    */

    /**
     * Create a new controller instance.
     *
     * @return void
    */
    public function __construct()
    {
        $this->middleware('auth');
    }

    /**
     * Handle a POST request to send message.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return void
    */
    public function send(Request $request) {
        $user = Auth::user();
        $dest = Dipendenti::where('username', $request->destinatario)->get()->first();
        $idDestinatario = $dest->IDDipendente;

        $message = messaggi::create([
            'testo' => htmlspecialchars($request->message),
            'idMittente' => $user->IDDipendente,
            'idDestinatario' => $idDestinatario
        ]);
        
        broadcast(new MessageSent($dest, $user, $message))->toOthers();

        return ['status' => 'Message Sent!'];
    }

    /**
     * Handle a POST request to receive new messages for each users.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return void
    */
    public function receive_messages(Request $request)
    {
        $id_user = Auth::user()->IDDipendente;
        $messaggi = [];

        foreach(self::getChat() as $dest ) {
            $id_dest = $dest->IDDipendente;

            $messaggi_ = messaggi::orWhere(function($q) use ($id_dest, $id_user) {
                            $q->where('idDestinatario', $id_dest)
                            ->where('idMittente', $id_user);
                        })
                        ->orWhere(function($query) use ($id_dest, $id_user) {
                            $query->where('idMittente', $id_dest)
                            ->where('idDestinatario', $id_user);
                        })
                        ->orderBy('created_at', 'asc')
                        ->get();

            $messaggi[$dest->username] = array();

            foreach($messaggi_ as $msg)
            {
                array_push( $messaggi[$dest->username], [
                    'testo' => htmlspecialchars($msg->testo), 
                    'orario' => $msg->created_at->toDateTimeString(),
                    'ricevuto' => $msg->idDestinatario == $id_user,
                ]);
            }
        }
        return json_encode($messaggi);

    }

    /**
     * Get default chat members for a client
     * 
     * 
     */ 
    public static function getChatMembersByClient() 
    {
        $idUser = Auth::user()->IDDipendente;
        $idAzienda = Auth::user()->idAzienda;
        $collaborazioni = Collaborazioni::where('idAziendaClienti', $idAzienda)->get();
        $members = [];

        foreach($collaborazioni as $collab)
        {
            $clienti = Dipendenti::where('idAzienda', $collab->idAziendaProgrammatori )->get();
            foreach( $clienti as $cliente )
            {
                $cliente->urlMedia = Media::where('idMedia', $cliente->idMedia)->get()->first()->urlMedia;

                array_push($members, $cliente);
            }
        }
        
        $colleghi = Dipendenti::where('idAzienda', $idAzienda)->where('IDDipendente', '!=', $idUser)->get();

        foreach($colleghi as $collega)
        {
            $collega->urlMedia = Media::where('idMedia', $collega->idMedia)->get()->first()->urlMedia;
            array_push($members, $collega);
        }

        return $members;
    }

    /**
     * Get default chat members for a coder
     * 
     * 
     */
    public static function getChatMembersByProgrammer() 
    {
        $idUser = Auth::user()->IDDipendente;
        $idAzienda = Auth::user()->idAzienda;
        $collaborazioni = Collaborazioni::where('idAziendaProgrammatori', $idAzienda)->get();
        $members = [];

        foreach($collaborazioni as $collab)
        {
            $clienti = Dipendenti::where('idAzienda', $collab->idAziendaClienti)->get();
            foreach( $clienti as $cliente )
            {
                $cliente->urlMedia = Media::where('idMedia', $cliente->idMedia)->get()->first()->urlMedia;
                array_push($members, $cliente);
            }
        }

        $colleghi = Dipendenti::where('idAzienda', $idAzienda)->where('IDDipendente', '!=', $idUser)->get();

        foreach($colleghi as $collega)
        {
            $collega->urlMedia = Media::where('idMedia', $collega->idMedia)->get()->first()->urlMedia;
            array_push($members, $collega);
        }

        return $members;

    }

    /**
     * Returns a list of chat.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return void
    */
    public static function getChat()
    {
        if( AziendeController::hasAzienda() ){

            if(AziendeController::isClient())
                return self::getChatMembersByClient();
            else
                return self::getChatMembersByProgrammer();
        }
    }

    /**
     * Get a validator for an incoming message send request.
     *
     * @param  array  $data
     * @return \Illuminate\Contracts\Validation\Validator
     */
    protected function validator(array $data)
    {
        return Validator::make($data, [
            'testo' => ['required', 'string', 'max:1000'],
            'username' => ['required', 'string', 'max:21']
        ]);
    }

}
