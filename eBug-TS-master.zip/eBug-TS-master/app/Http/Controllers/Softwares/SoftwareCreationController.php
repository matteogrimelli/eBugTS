<?php

namespace App\Http\Controllers\Softwares;

use App\affidamentoSoftware;
use App\Http\Controllers\Controller;
use App\Aziende;
use Illuminate\Http\Request;
use App\Providers\RouteServiceProvider;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Validator;
use App\collaborazioni;
use Illuminate\Validation\Rule;
use App\Dipendenti;
use App\Http\Controllers\Company\AziendeController;
use App\Softwares;

class SoftwareCreationController extends Controller
{
    /*
    |--------------------------------------------------------------------------
    | Software Creation Controller
    |--------------------------------------------------------------------------
    |
    | This controller handles the creation of new softwares.
    |
    */

    /**
     * Where to redirect users after software creation.
     *
     * @var string
     */
    protected $redirectTo = RouteServiceProvider::HOME;

    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }

    /**
     * Handle a POST software creation request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\RedirectResponse
    */
    public function create_post(Request $request)
    {
        # Validate user input
        $this->validator1($request->all())->validate();

		$idClienti = Aziende::where('nome', $request->nomeAziendaClienti)->get()->first()->IDAzienda;
		$idProgrammatori = Auth::user()->idAzienda;

		# Check if collaborazione already exists
		$query = collaborazioni::where('idAziendaClienti', $idClienti)->where('idAziendaProgrammatori', $idProgrammatori)->get();
		if($query->isNotEmpty()) {
			$idCollaborazione = $query->first()->IDCollaborazione;
		}

		# Else create it
		else {
			$idCollaborazione =	collaborazioni::create([
						'idAziendaClienti' => $idClienti,
						'idAziendaProgrammatori' => $idProgrammatori
			])->IDCollaborazione;
        }

        $request = array_merge($request->all(), ['idCollaborazione' => $idCollaborazione]);

   	    # Validate user input
        $this->validator2($request)->validate();

		# Create software
        $idSoftware = $this->create($request)->IDSoftware;
        
        # Redirect the user
        return redirect($this->redirectPath());

    }


    /**
     * Get a validator for an incoming request.
     *
     * @param  array  $data
     * @return \Illuminate\Contracts\Validation\Validator
     */
    protected function validator2(array $data)
    {
        return Validator::make($data, [
            'nome' => ['required', 'string', 'min:8',
				Rule::unique('softwares')->where(function ($query) use(&$data){
					return $query->where('idCollaborazione', $data['idCollaborazione']);
				})
            ],
            'descrizione' => ['string', 'max:100'],
        ]);
    }


    /**
     * Get a validator for an incoming request.
     *
     * @param  array  $data
     * @return \Illuminate\Contracts\Validation\Validator
     */
    protected function validator1(array $data)
    {
        return Validator::make($data, [
            'nomeAziendaClienti' => ['required', 'string', 'min:1', 'max:40']
        ]);
    }

    /**
     * Create a new user instance after a valid request
     *
     * @param  array  $data
     * @return \App\Softwares
     */
    protected function create(array $data)
    {
        return Softwares::create([
            'nome' => $data['nome'],
            'descrizione' => $data['descrizione'],
            'idCollaborazione' => $data['idCollaborazione'],
        ]);
    }


	public function show()
	{
        # Check if user has a company
        if( ! AziendeController::hasAzienda() ){
            return redirect('nocompany');
        }

        # Only developers can create softwares
        if( AziendeController::isClient() ){
            abort(403);
        }

		$aziendeClienti = Aziende::where('tipoAzienda', 0)->get();
		return view('softwares.create')->with('aziendeClienti', $aziendeClienti);
	}

    /**
     * Get the post software creation redirect path.
     *
     * @return string
     */
    public function redirectPath()
    {
        if (method_exists($this, 'redirectTo')) {
            return $this->redirectTo();
        }

        return property_exists($this, 'redirectTo') ? $this->redirectTo : '/home';
    }

}

?>
