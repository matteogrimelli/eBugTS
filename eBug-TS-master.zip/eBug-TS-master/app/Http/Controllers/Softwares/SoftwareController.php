<?php

namespace App\Http\Controllers\Softwares;

use App\Media;
use App\Dipendenti;
use App\aggiornamentiBug;
use App\Bugs;
use App\Softwares;
use App\affidamentoSoftware;
use App\Aziende;
use App\collaborazioni;
use App\Http\Controllers\Company\AziendeController;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class SoftwareController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }

    /**
     * Returns the given software's page
     */
    public function show(Request $request)
    {
        $software_name = urldecode($request->software_name);
        $idAzienda = Auth::user()->idAzienda;
        $company = Aziende::where('IDAzienda', $idAzienda)->get()->first();

        # Check user's company type
        if($company->tipoAzienda == 1)
        {
            $software = $this::getSoftwareByNameProgrammer($software_name);

        } else {
            $software = $this::getSoftwareByNameClient($software_name);
        }

        if (!empty($software)) {
            return view('softwares.show')->with('software', $software);
        }

        # If no softwares with that name were found
        abort(404);

    }

    # This method returns the software with the given name developed by the programmer
    public static function getSoftwareByNameProgrammer($software_name) {

        $idAzienda = Auth::user()->idAzienda;

        $collaborazioni = collaborazioni::where('idAziendaProgrammatori', $idAzienda)->get();

            foreach ($collaborazioni as $collab) {

                $software = Softwares::where('idCollaborazione', $collab->IDCollaborazione)
                            ->where('nome', $software_name)->get()->first();
                if(!empty($software))
                {
                    $aziendaSviluppatrice = Aziende::where('IDAzienda', $collab->idAziendaProgrammatori)->get()->first();

                    $software->aziendaSviluppatrice = $aziendaSviluppatrice->nome;
                    $software->urlMedia = Media::where('IDMedia', $aziendaSviluppatrice->idMedia)->get()->first()->urlMedia;
                    return $software;
                }
            }
    }

    # This method returns the software with the given name bought by the client
    public static function getSoftwareByNameClient($software_name) {

        $idAzienda = Auth::user()->idAzienda;

        $collaborazioni = collaborazioni::where('idAziendaClienti', $idAzienda)->get();

            foreach ($collaborazioni as $collab) {

                # This might return more that one entry and that's why it needs be to fixed
                $software = Softwares::where('idCollaborazione', $collab->IDCollaborazione)
                            ->where('nome', $software_name)->get()->first();
                if(!empty($software))
                {
                    $aziendaSviluppatrice = Aziende::where('IDAzienda', $collab->idAziendaProgrammatori)->get()->first();

                    $software->aziendaSviluppatrice = $aziendaSviluppatrice->nome;
                    $software->urlMedia = Media::where('IDMedia', $aziendaSviluppatrice->idMedia)->get()->first()->urlMedia;
                    return $software;
                }
            }
    }

    public static function getSoftwaresByProgrammer() {
        $softwares = [];

        $collaborazioni = collaborazioni::where('idAziendaProgrammatori', Auth::user()->idAzienda)->get();

        foreach($collaborazioni as $collab)
        {
            $softwares_ = Softwares::where('idCollaborazione', $collab->IDCollaborazione)->get();
            foreach($softwares_ as $software)
            {
                $software_name = $software->nome;
                array_push($softwares, $software_name);
            }
        }
        return $softwares;
    }

    public static function getSoftwaresByClient() {
        $softwares = [];

        $collaborazioni = collaborazioni::where('idAziendaClienti', Auth::user()->idAzienda)->get();

        foreach($collaborazioni as $collab)
        {
            $softwares_ = Softwares::where('idCollaborazione', $collab->IDCollaborazione)->get();
            foreach($softwares_ as $software)
            {
                $software_name = $software->nome;
                array_push($softwares, $software_name);
            }
        }
        return $softwares;
    }

    public static function getFullSoftwaresByProgrammer() {
        $softwares = [];

        $collaborazioni = collaborazioni::where('idAziendaProgrammatori', Auth::user()->idAzienda)->get();

        foreach($collaborazioni as $collab)
        {
            foreach(Softwares::where('idCollaborazione', $collab->IDCollaborazione)->get() as $software) {
                array_push($softwares, $software);
            }
        }
        return $softwares;
    }

    public static function getFullSoftwaresByClient() {
        $softwares = [];

        $collaborazioni = collaborazioni::where('idAziendaClienti', Auth::user()->idAzienda)->get();

        foreach($collaborazioni as $collab)
        {
            foreach(Softwares::where('idCollaborazione', $collab->IDCollaborazione)->get() as $software) {
                array_push($softwares, $software);
            }
        }
        return $softwares;
    }

    public static function getSoftwareByName($software_name) {
        if( AziendeController::isClient() ) return self::getSoftwareByNameClient($software_name);
        else return self::getSoftwareByNameProgrammer($software_name);
    }

    public static function getSoftwares() {
        if( AziendeController::isClient() ) return self::getSoftwaresByClient();
        else return self::getSoftwaresByProgrammer();
    }

    public static function getFullSoftwares() {
        if( AziendeController::isClient() ) return self::getFullSoftwaresByClient();
        else return self::getFullSoftwaresByProgrammer();
    }

    public static function getFeed() {
        $timestamp_past_max = time() - (2 * 7 * 24 * 60 * 60);
        $updates = [];

        foreach(self::getFullSoftwares() as $software){
            
            $idSoftware = $software->IDSoftware;

            $bugs = Bugs::select('IDBug')->where('idSoftware', $idSoftware)->get();

            $software_name = Softwares::select('nome')->where('IDSoftware', $idSoftware)->first()->nome;

            foreach ($bugs as $bug) {
                $aggiornamentiBug = aggiornamentiBug::where('created_at', '>', $timestamp_past_max)
                                        ->where('idBug', $bug->IDBug)->get();

                foreach ($aggiornamentiBug as $update) {
                    $dipendenti = Dipendenti::select('username', 'idMedia')
                                    ->where('IDDipendente', $update->idCreatore)
                                    ->first();

                    $update['username'] = $dipendenti->username;
                    $update['urlMedia'] = Media::where('IDMedia', $dipendenti->idMedia)->first()->urlMedia;
                    $update['softwareName'] = $software_name;

                    array_push($updates, $update);
                }
            }
        }
        return $updates;
    }

}
?>
