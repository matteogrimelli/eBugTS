<?php
namespace App\Http\Controllers\Company;

use App\Aziende;
use App\Http\Controllers\Controller;
use App\Media;
use App\collaborazioni;
use App\Dipendenti;
use App\invitiaziende;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Request;
use Illuminate\Support\Str;

class AziendeController extends Controller
{
    /*
    |--------------------------------------------------------------------------
    | Aziende Controller
    |--------------------------------------------------------------------------
    |
    | This controller handles the companies.
    |
    */

    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }

    /**
     * Returns User's Company
     */
    public static function getAzienda() {
        return Aziende::where('IDAzienda', Auth::user()->idAzienda)->get()->first();
    }

    /**
     * Returns User's Company with its media's url
     */
    public static function getAziendaWMedia() {
        $company = Aziende::where('IDAzienda', Auth::user()->idAzienda)->get()->first();
        $company->urlMedia = self::getUrlMediaAzienda();
        return $company;
    }

    /**
     * Check whether the user is a client or a programmer
     */
    public static function isClient() {
        if ( self::hasAzienda() ) {
            if(Aziende::where('IDAzienda', Auth::user()->idAzienda)->get()->first()->tipoAzienda == 0)
                return TRUE;
            else
                return FALSE;
        }
    }

    /**
     * Check whether the user has an azienda or not
     */
    public static function hasAzienda()
    {
        if( isset(Auth::user()->idAzienda) )
            return TRUE;
        else 
            return FALSE;
    }

    /**
     * Show the users' company profile, if he has one
     *
     */
    public function index()
    {
        if( self::hasAzienda() )
            return view('company.company');
        else
            return redirect('nocompany');
    }

    /**
     * POST endpoint to generate invite link for companies
     *
     */
    public function invite_dipendente() {
        if( !self::hasAzienda() ) return redirect(503);

        $idazienda = self::getAzienda()->IDAzienda;
        $token = str::random(32);

        invitiaziende::create([
                'token' => $token,
                'idAzienda' => $idazienda
        ]);

        return url("/company/join/$token");
    }

    /**
     * GET endpoint to generate invite link for companies
     *
     */
    public function join_company(Request $request, $token) {
        if( self::hasAzienda() ) return redirect(503);

        $invito = invitiaziende::where('token', $token)->get()->first();
        if(!empty($invito))
        {
            # Set user's idAzienda
            $user = Dipendenti::find( Auth::user()->IDDipendente );
            $user->idAzienda = $invito->idAzienda;
            $user->save();
            
            // delete invite from db
            invitiaziende::where('IDInvito', $invito->IDInvito)->delete();

            return redirect('/company');
        }

        return redirect(498);
    }

    public static function getAffiliates() {
        $idAzienda = self::getAzienda()->IDAzienda;
        $affiliates = [];

        $collabs = collaborazioni::where(self::isClient() ? 'idAziendaClienti' : 'idAziendaProgrammatori', $idAzienda)->get();
        foreach($collabs as $collab)
        {
            array_push($affiliates, Aziende::where('IDAzienda', self::isClient() ? $collab->idAziendaProgrammatori : $collab->idAziendaClienti)->get()->first()->nome);
        }
        return $affiliates;
    }

    public static function getUrlMediaAzienda() {
        return Media::where('IDMedia', self::getAzienda()->idMedia)->get()->first()->urlMedia;
    }

    /**
     * Let the user decide whether to create or to join an existing company, if he doesn't already have one
     *
     */
    public function nocompany()
    {
        if(self::hasAzienda())
        {
            return redirect('/company');
        }
        else
        {
            return view('company.nocompany');
        }
    }

}
