<?php

namespace App\Http\Controllers\Company;

use App\Aziende;
use App\Dipendenti;
use App\Http\Controllers\Controller;
use App\Http\Controllers\Company\AziendeController;
use App\Media;
use Illuminate\Support\Facades\Validator;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Validation\Rule;

class AziendeCreationController extends Controller
{
    /*
    |--------------------------------------------------------------------------
    | Aziende Creation Controller
    |--------------------------------------------------------------------------
    |
    | This controller handles the creation of new companies as well as their functions.
    |
    */

    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }

    /**
     * Handle a creation request for a new company.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return void
     */
    public function register(Request $request)
    {

        # Validate user input
        $this->validator($request->all())->validate();

        # Create the Media uploaded
        if($request->hasFile('companyimage')) {

            # Generate unique filename and store the image in /public/storage/images/
            $path = $request->file('companyimage')->store('public/images');
            $path = str_replace('public', 'storage', $path);

            # Save the media into the DB and get its id
            $IDMedia = Media::create([
                'urlMedia' => $path
            ])->IDMedia;

        }
        else {
            # Default company image
            # 5 - client company 1
            # 6 - coders company 1
            if( $request->tipoAzienda == 0)
                $IDMedia = 5;
            else
                $IDMedia = 6;
        }

        # Create the company
        $company = $this->create( array_merge($request->all(), ['idMedia' => $IDMedia]) );

        # Set user's idAzienda
        $user = Dipendenti::find( Auth::user()->IDDipendente );
        $user->idAzienda = $company->IDAzienda;
        $user->save();

        # Redirect the user after creating the company
        return $this->created($request, $company);
    }

    /**
     * Get a validator for an incoming registration request.
     *
     * @param  array  $data
     * @return \Illuminate\Contracts\Validation\Validator
     */
    protected function validator(array $data)
    {
        return Validator::make($data, [
            'nome' => ['required', 'string', 'max:41', 'unique:aziende'],
            'email' => ['nullable', 'string', 'max:61'],
            'telefono' => ['nullable', 'string', 'max:11'],
            'tipoAzienda' => ['nullable', 'int', Rule::in([0, 1]) ],
            'localita' => ['nullable', 'string', 'max:101'],

        ]);
    }

    /**
     * Create a new user instance after a valid company registration.
     *
     * @param  array  $data
     * @return \App\Aziende
     */
    protected function create(array $data)
    {
        return Aziende::create([
            'nome' => $data['nome'],
            'email' => $data['email'] ?? '',
            'telefono' => $data['telefono'] ?? '',
            'tipoAzienda' => $data['tipoAzienda'],
            'localita' => $data['localita'] ?? '',
            'idMedia' => $data['idMedia']
        ]);
    }

    /**
     * The company has been created.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  mixed  $company
     * @return mixed
     */
    protected function created(Request $request, $company)
    {
        return redirect('/company');
    }

    /**
     * Show the users' company profile, if he has one
     *
     */
    public function show()
    {
        if( AziendeController::hasAzienda()  )
            return view('company.company');
        else
            return view('company.create-company');
    }

}
