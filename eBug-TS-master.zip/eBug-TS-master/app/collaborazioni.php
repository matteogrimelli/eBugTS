<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class collaborazioni extends Model
{
    # Overrides deafult table name, which by default is 'collaborazionis, s would be added as a plural
    protected $table = 'collaborazioni';

    # Overrides default primary key name, which by default is 'id'
    protected $primaryKey = 'IDCollaborazione';

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'timestampCollaborazione',
        'idAziendaClienti',
        'idAziendaProgrammatori'
    ];

    /**
     * The attributes that are NOT mass assignable.
     *
     * @var array
     */
    protected $guarded = [
        'IDCollaborazione', 'created_at', 'updated_at'
    ];

}
