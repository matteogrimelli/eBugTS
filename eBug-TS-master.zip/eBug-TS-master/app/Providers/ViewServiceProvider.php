<?php

namespace App\Providers;

use Illuminate\Support\Facades\View;
use Illuminate\Support\ServiceProvider;
use App\Http\Controllers\Chat\ChatController;
use App\Http\Controllers\Company\AziendeController;
use App\Http\Controllers\Softwares\SoftwareController;

class ViewServiceProvider extends ServiceProvider
{
    /**
     * Register any application services.
     *
     * @return void
     */
    public function register()
    {
        //
    }

    /**
     * Bootstrap any application services.
     *
     * @return void
     */
    public function boot()
    {
        View::composer('layouts.layout', function( $view )
        {
            $view->with('has_company', AziendeController::hasAzienda() )
                ->with('is_dev', ! AziendeController::isClient() )
                ->with('softwares', SoftwareController::getSoftwares() )
                ->with('visible_chats', ChatController::getChat() );
        });

        View::composer('company.company', function( $view )
        {
            $view->with('company', AziendeController::getAziendaWMedia())
                ->with('softwares', SoftwareController::getSoftwares())
                ->with('affiliates', AziendeController::getAffiliates() );
        });

        View::composer('bugs.report', function( $view )
        {
            $view->with('softwares', SoftwareController::getFullSoftwares());
        });

    }
}