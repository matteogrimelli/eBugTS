<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class invitiaziende extends Model
{
    # Overrides deafult table name
    protected $table = 'invitiaziende';

    # Overrides default primary key name, which by default is 'id'
    protected $primaryKey = 'IDInvito';

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'idAzienda',
        'token'
    ];

    /**
     * The attributes that are NOT mass assignable.
     *
     * @var array
     */
    protected $guarded = [
        'IDInvito', 'created_at', 'updated_at'
    ];

}
