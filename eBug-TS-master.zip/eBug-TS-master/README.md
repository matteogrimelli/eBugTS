# eBug Tracking System 

## Installation ✅ 
### 0 - Install php >= 7.2
### 1 - Installare composer

#### Linux
```bash
php -r "copy('https://getcomposer.org/installer', 'composer-setup.php');"
php -r "if (hash_file('sha384', 'composer-setup.php') === 
'e0012edf3e80b6978849f5eff0d4b4e4c79ff1609dd1e613307e16318854d24ae64f26d17af3ef0bf7cfb710
ca74755a') { echo 'Installer verified'; } 
else { echo 'Installer corrupt'; unlink('composer-setup.php'); } echo PHP_EOL;"
php composer-setup.php
php -r "unlink('composer-setup.php');"
mv composer.phar /usr/local/bin/composer
```

#### Windows
[Scaricare e avviare l'installer di composer](https://getcomposer.org/Composer-Setup.exe)

Nota Bene: Riavvia tutte le istanze di CMD per rendere effettive le modifiche al PATH

### 2 - Installare NPM
#### Linux
```bash
sudo apt-get install nodejs
```
#### Windows
https://nodejs.org/en/download/

### 3 - Scaricare il progetto
```bash
git clone https://github.com/Bonfee/eBug-TS.git
```

### 4 - Installare le dipendenze di composer
```bash
cd eBug-TS/
composer install
```

### 5- Installare le dipendenze di npm
```bash
cd eBug-TS/
npm install
```

### 6 - Crea una copia del tuo file .env
#### Linux
```bash
cd eBug-TS/
cp .env.example .env
```

#### Windows
```cmd
cd eBug-TS/
copy .env.example .env
```

### 7 - Crea una encryption key per l'app
```bash
cd eBug-TS/
php artisan key:generate
```

### 8 - Avvia XAMPP
#### 8.1 - Spostati nel tab *"Manage Servers"*
#### 8.2 - Seleziona Apache Web Server e clicca *"Configure"*
#### 8.3 - Clicca su *"Open Conf File*" e clicca *"Si*" se ti viene chiesta un ulteriore conferma
#### 8.4 - Nel file che si apre modifica - sostituendo *"path-to"* con il percorso alla cartella del progetto

#### Windows
```bash
DocumentRoot "C:/path-to/eBug-TS/public"
<Directory "C:/path-to/eBug-TS/public">
```

#### Linux
```bash
DocumentRoot "/path-to/eBug-TS/public"
<Directory "/path-to/eBug-TS/public">
```

### 9 - Torna su XAMPP e avvia il server Apache e MySQL

### 10 - Vai su http://localhost/phpymadmin
#### Crea un database chiamato "*ebugts*"

### 11 - Modifica nel file .env le seguenti righe
```bash
DB_DATABASE=ebugts
DB_USERNAME=root
DB_PASSWORD=
```

### 12 - Table Migration
```bash
cd eBugTS/
php artisan migrate
```
### 13 - Image folder link
```bash
cd eBugTS/
php artisan storage:link
```
### 13 - Finito ora puoi programmare
#### 13.1 - Come puoi notare, su http://localhost/phpymadmin, nel database ebugts ci sono ora tutte le table del progetto
## Contributors ✨
💻 PHP and JS Programmer
- **Bonforte Vincenzo** 

🎨 CSS Designer 
- **Grimelli Matteo** 

📆 Project Manager
- **Beltrami Giacomo** 
